# 08｜作者的实验与结果：看原图，但不冒充已复现

> **本章是原文报告。** 表中数字来自正式PDF第7页，保存在`source/reported_tables.json`。没有取得作者原始预测和补充代码，所以不是本次重新计算的成绩；新增实跑见第09章。

## 8.1 合成：已知真实因素，控制混合复杂度

作者从高斯分布采样二维/三维$z$，按行为规则分组，再用线性、非线性稀疏、非线性稠密函数得到$x$。VAE产生$g(x)$，再训练解释瓶颈。

“稀疏混合函数”说的是每个观测分量依赖较少因素；“单稀疏CDC”说的是组间变化。它们是不同的稀疏性。

<figure class="study-figure"><img src="../assets/figures/original_table1.png" alt="原文表1，六个合成设置及作者分数"><figcaption>原表1（PDF第7页）：颜色是作者设定的行为组。右表全部为原文报告，粗体是作者显著性标记，不表示本次重新计算了p值。</figcaption></figure>

作者报告CDC的D在六种设置中为1.00、0.97、0.90、0.99、0.92、0.89。它说明作者实现的受控实验有很强的逐轴恢复效果，不能从中直接推出任意真实LM或任意分组也成立。

二维高斯的均值/方差、精确分组阈值、完整三维分组代码、评价器细节未充分给出。本次把这些缺口列入独立约定，没有按作者表反向调参。

## 8.2 半合成：真实文本，人工行为标签

作者使用20000条BiasBios简介，真实因素是二元性别与高/中/低职业收入等级。收入等级来自职业男性收入中位数的1/3、2/3分位数，行为由人工规则模拟。

作者测试DistilBERT-base、Qwen2-7B和Llama-3.1-8B；本次并未按这些原规模逐一执行。

<figure class="study-figure"><img src="../assets/figures/original_table2.png" alt="原文表2，三种模型的半合成实验"><figcaption>原表2（PDF第7页）：作者报告DistilBERT、Qwen、Llama的CDC D为0.91、0.80、0.86；本次缩小文本实验不能替代这张表。</figcaption></figure>

这里最重要的对照是：行为预测帮助保留相关因素，但加入作者约束后D/C显著提高。仍要记住标签是模拟的，所以不是证明这些LM自然具有同样的收入偏见或相同内部因果机制。

## 8.3 拒答案例：没有概念真值时怎么解释

作者取有害、无害、伪有害三类提示各500条。行为分组来自拒答概率的高/中/低，不直接使用这些提示类型标签训练解释器。

拒答概率基于常见拒答开头，如“I am sorry”和“I cannot”。这是一个行为测量代理：可能漏掉其他措辞，也可能把普通表达误算为拒答。完整复现需要明确tokenization、序列概率合并与聚类细节。

<figure class="study-figure"><img src="../assets/figures/original_figure2.png" alt="原图2 Llama拒答学习空间，颜色与点形分别编码不同信息"><figcaption>原图2（PDF第8页）：颜色是真实提示类型，形状是拒答概率组。右图呈近轴对齐，被作者解释为伤害性与主题；没有概念真值和实际干预检验时，这仍是案例解释而非正式因果鉴定。</figcaption></figure>

读图顺序：先看颜色（任务类型），再看形状（行为），最后看是否沿单轴分开。中图已把类型分开，但方向混合；右图看起来更接近“一个轴对应一种差异”。

<figure class="study-figure"><img src="../assets/figures/original_figure7.png" alt="原图7 Qwen拒答案例的三个方法空间"><figcaption>原图7（PDF第21页，附录C）：作者报告Qwen也出现类似结构。本次没有运行此模型，未复制其点坐标或拒答概率。</figcaption></figure>

## 8.4 与SAE比较的三种评价

作者取LlamaScope残差流的32层×2种宽度，共64个SAE；整个资源另包含其他子层，不能把“使用64个”误读成“资源仅有64个”。

1. **全特征：** 看32k/128k特征整体保留多少因素信息。
2. **行为相关top-2：** 先线性预测$c$，选最有用的两个特征，与本文二维瓶颈比较。
3. **真值相关top-2上限：** 直接用每个真实因素训练分类器，各选一个最有用特征；这额外用了概念标签，是上限分析。

<figure class="study-figure"><img src="../assets/figures/original_figure3.png" alt="原图3，32k SAE的全特征、行为top2、真值top2评价"><figcaption>原图3（PDF第8页）：三列是三种不同选择规则。虚线为层间均值，阴影为±1 SD；并不代表本次独立重新训练SAE。</figcaption></figure>

作者报告全32k特征$I=0.95\pm0.07$、$D=0.58\pm0.07$；行为top-2后$I=0.57\pm0.02$、$D=0.08\pm0.12$；真值top-2的最高D为0.76，对应I为0.62。

这说明分布式大字典的信息可能不能压成两条现成特征。它不是“SAE完全没有这些信息”：全特征I很高。SAE也没有与CDC完全相同的行为目标，所以需要区分任务差异与表示质量差异。

<figure class="study-figure"><img src="../assets/figures/original_figure8.png" alt="原图8，128k SAE的三个评价"><figcaption>原图8（PDF第21页）：作者报告128k宽度结论相似。图上的逐层精确数值未取得，不从图片读近似像素值冒充原始数据。</figcaption></figure>

## 8.5 作者使用的算力

<figure class="study-figure"><img src="../assets/figures/original_table3.png" alt="原表3，GPU、内存和原文运行时间"><figcaption>原表3（PDF第20页）：7B/8B半合成实验使用4GPU、256GB内存、约17小时；这是作者报告，不是本机计时。</figcaption></figure>

本机约16GB内存且无CUDA；所以本次选择透明的CPU缩小实验，不伪装成同规格复现，也没有自动租用GPU。

## 8.6 能与不能从原表重算什么

- 可以：抄录校验；对已四舍五入分数做明确标记的算术差。
- 不可以：还原逐样本预测、准确p值、随机种子方差、全部模型检查点、图中每个点坐标。
- 不可以：根据均值自行补造误差条，再称经过复现。

本次公开`reported_tables.json`和来源页码用于追踪；新增表只从实际日志生成。两类证据有清晰的分界。
