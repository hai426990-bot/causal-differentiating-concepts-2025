# 05｜定理1完整推导：哪些条件才能推出仿射恢复

## 5.1 原文结论与需要核查的地方

**原文定理1：** 满足假设1，且最优满足公式(3)的编码器，可以恢复真实潜变量到可逆仿射变换。

附录A的路线是：交叉熵最优 → 类别概率相同 → logits相差一个公共项 → 堆叠方程并求逆。

这里有两个实质问题：公共归一化差通常依赖输入；$m>d$不自动保证矩阵满秩，可逆也不能直接用在长方形矩阵上。

下面给出**添加明确条件后的严谨版本**，不把它冒充原文已经写出的全部假设。

## 5.2 条件化命题

设真实概念$z(x)\in\mathbb R^d$，学习表示$f(x)\in\mathbb R^d$。假设：

1. 真实与学习条件概率均为线性logits softmax，可允许截距；
2. 训练类可实现真实条件概率，且总体交叉熵达到其最低值；
3. $z(x)$的支撑仿射张成$\mathbb R^d$；
4. 以一个参考类别作差，真实权重差矩阵$B$列秩为$d$。

则在相关支撑上，$f(x)=Az(x)+b$，其中$A$可逆。

至少需要$m-1\ge d$，但类别数足够只是容纳满秩的必要条件，不是满秩本身。

<figure class="study-figure"><img src="../assets/figures/teaching_rank.svg" alt="平行权重无论数量多少都不能覆盖两维"><figcaption>教学图：真正起作用的是类别参考权重差的独立方向，不只是类别数。</figcaption></figure>

## 5.3 第一步：从交叉熵到正确概率

总体风险满足

$$
\mathcal R(q)=\mathbb E_x H(p(\cdot\mid x))+
\mathbb E_x D_{\rm KL}(p(\cdot\mid x)\Vert q(\cdot\mid x)).
$$

可实现且达到最优时，KL项几乎处处为0，故$q(c\mid x)=p(c\mid x)$。默认是分布意义的“几乎处处”；若要所有$x$成立，还需要连续性等条件延拓，不能自动升级。

## 5.4 第二步：用参考类别而不是丢掉归一化

真实logits为$w_c^\top z+\beta_c$，学习logits为$q_c^\top f+\alpha_c$。选类别0：

$$
\log\frac{p(c\mid x)}{p(0\mid x)}
=(w_c-w_0)^\top z+\beta_c-\beta_0,
$$

$$
\log\frac{q(c\mid x)}{q(0\mid x)}
=(q_c-q_0)^\top f+\alpha_c-\alpha_0.
$$

两者相等，堆叠$c=1,\ldots,m-1$得到

$$
Bz+\gamma=Qf+\eta.\qquad (\star)
$$

其中$B,Q\in\mathbb R^{(m-1)\times d}$。所有偏移已明确成为**模型参数截距差**，不是把输入相关的log-sum-exp误当成常数。

## 5.5 第三步：为什么学习矩阵Q也满秩

任取支撑中的参考点$x_0$，用$(\star)$相减：

$$
B[z(x)-z(x_0)]=Q[f(x)-f(x_0)].
$$

因为真实支撑仿射满维，$z(x)-z(x_0)$张成$d$维；$B$列满秩，因此左侧张成维数$d$。右侧都位于$Q$的列空间，所以$\operatorname{rank}(Q)\ge d$。

而$Q$只有$d$列，因此$\operatorname{rank}(Q)=d$。

## 5.6 第四步：左逆求出A，再证明可逆

列满秩长方形矩阵有左逆

$$
Q^\dagger=(Q^\top Q)^{-1}Q^\top,\qquad Q^\dagger Q=I_d.
$$

左乘$(\star)$：

$$
f=Q^\dagger Bz+Q^\dagger(\gamma-\eta)=Az+b.
$$

由支撑差分张成全空间，还得到$QA=B$。于是

$$
d=\operatorname{rank}(B)=\operatorname{rank}(QA)
\le\operatorname{rank}(A)\le d.
$$

所以$A$满秩、可逆。证毕。

**额外观察：** 若两边都严格无截距，参考log-odds方程没有常数项，可能得到更强的线性形式。本文保留仿射版本，以兼容实际带偏置分类头。

## 5.7 精确算例：左逆确实恢复原矩阵

取

$$
B=\begin{pmatrix}1&0\\0&1\\1&1\end{pmatrix},\quad
A=\begin{pmatrix}2&1\\-1&3\end{pmatrix},\quad Q=BA^{-1}.
$$

$\det A=7$，且

$$
Q=\frac17\begin{pmatrix}3&-1\\1&2\\4&1\end{pmatrix}.
$$

符号计算给出$Q^\dagger B=A$，不是只在一个数值输入上“碰巧成立”。代码使用SymPy有理数精确运算。

## 5.8 反例：类别数多仍可不识别

令$d=2,m=4$，真实logits是

$$
\ell_c(z)=c(z_1+z_2),\qquad c=0,1,2,3.
$$

它满足logit线性softmax，却只依赖一个组合$z_1+z_2$。令

$$
f(z)=\big(z_1+z_2,\ (z_1-z_2)^3\big).
$$

用学习权重$q_c=(c,0)$，对所有$z$，学习logits与真实logits完全相同，交叉熵达到相同最优；但$f$不是仿射映射，第二坐标Hessian一般非零。

这个$f$甚至保留了两维信息：由和及差的立方能恢复原坐标。因此问题不只是“编码器丢掉了一维”，而是分类概率根本没有约束另一维的坐标形状。

**范围：** 这是对“假设1单独足以推出定理1”这一表述的诊断；不声称它同时满足假设2并反驳所有后续结论。

## 5.9 读完定理1应带走什么

正确的核心思想是：足够丰富的**线性log-odds**可以把表征等价类压缩到仿射类。不能省略“足够丰富”的秩与支撑条件，也不能把实际有限训练直接等同于总体最优证明。
