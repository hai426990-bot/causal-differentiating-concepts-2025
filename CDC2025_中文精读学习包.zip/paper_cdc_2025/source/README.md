# 原始材料与复现边界

目标论文：**Causal Differentiating Concepts: Interpreting LM Behavior via Causal Representation Learning**，Navita Goyal、Hal Daumé III、Alexandre Drouin、Dhanya Sridhar，NeurIPS 2025。

- 用户指定的正式论文：https://proceedings.neurips.cc/paper_files/paper/2025/file/5faf0f518f39e4d6b2b595e3ca2fe0c4-Paper-Conference.pdf
- 正式摘要：https://proceedings.neurips.cc/paper_files/paper/2025/hash/5faf0f518f39e4d6b2b595e3ca2fe0c4-Abstract-Conference.html
- OpenReview：https://openreview.net/forum?id=Zf6Oj5x9sE

本目录保留版本、文件散列、作者代码出处与计算环境。中文教学解释与独立实验不冒充作者结论。

实验标签必须区分：作者报告数值、官方代码复现、缩小规模复现、教学诊断、尚未执行。有限点数值检验不能替代一般数学证明；无法计算核实的作者数据不得标成已复现。
