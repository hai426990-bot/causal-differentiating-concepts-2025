const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname, out = path.join(root, 'output'), chapterDir = path.join(root, 'chapters');
fs.mkdirSync(out, { recursive: true });
require('./make-figures.cjs');
const glossary = require('./glossary.cjs');
const ids = new Set();
for (const entry of glossary) {
  if (ids.has(entry.id)) throw new Error('Duplicate glossary ID: '+entry.id);
  ids.add(entry.id);
  for (const key of ['id','name','english','group','intuition','definition','example','paper','warning']) if (typeof entry[key] !== 'string' || !entry[key].trim()) throw new Error('Missing glossary '+entry.id+'.'+key);
}
let md = '# 词典｜中英术语随查：直觉、定义、例子与用途\n\n';
md += `共${glossary.length}个教学词条，通用基础与CDC专用概念分组。不要从头背；先读[基础补课](00_basics.md)。原文术语和本次补充条件会区分。\n\n`;
for (const [i, group] of [...new Set(glossary.map(e => e.group))].entries()) {
  md += `<h2 id="glossary-group-${i}">${group}</h2>\n\n`;
  for (const e of glossary.filter(t => t.group === group)) md += `<h3 id="term-${e.id}">${e.name} · ${e.english}</h3>\n\n**直觉：** ${e.intuition}\n\n**定义：** ${e.definition}\n\n**例子：** ${e.example}\n\n**在论文中的用途：** ${e.paper}\n\n> **别混淆：** ${e.warning}\n\n`;
}
fs.writeFileSync(path.join(chapterDir, '14_glossary.md'), md);
const chapters = fs.readdirSync(chapterDir).filter(f => f.endsWith('.md')).sort().map(file => {
  const markdown = fs.readFileSync(path.join(chapterDir,file),'utf8');
  const title = markdown.match(/^#\s+(.+)$/m)?.[1];
  if (!title) throw new Error('Missing chapter title '+file);
  return {id:file.slice(0,-3),file,title,markdown};
});
if (chapters.length !== 16) throw new Error('Expected 16 sections, got '+chapters.length);
const media = {}, images = [];
for (const c of chapters) {
  const refs = [...c.markdown.matchAll(/<img\b[^>]*\bsrc="([^"]+)"/g)].map(m=>m[1]);
  refs.push(...[...c.markdown.matchAll(/!\[[^\]]*\]\(([^)]+)\)/g)].map(m=>m[1]));
  for (const src of refs) {
    if (/^(?:https?:|data:|\/)/.test(src)) throw new Error('Use local image '+src);
    const file=path.resolve(chapterDir,src);if(!file.startsWith(root+path.sep))throw new Error('Image outside project');
    const bytes=fs.readFileSync(file), ext=path.extname(file).toLowerCase();
    const mime={'.svg':'image/svg+xml','.png':'image/png'}[ext];if(!mime)throw new Error('Unknown image format');
    let width,height;
    if(ext==='.png'){width=bytes.readUInt32BE(16);height=bytes.readUInt32BE(20);}
    else {const match=bytes.toString().match(/\bviewBox="([\d.\s-]+)"/);if(!match)throw new Error('Missing viewBox '+file);[,,width,height]=match[1].split(/\s+/).map(Number);}
    media[src]={path:path.relative(root,file).split(path.sep).join('/'),mime,width,height,dataURI:`data:${mime};base64,${bytes.toString('base64')}`};
    images.push({chapter:c.file,src,path:media[src].path,width,height,sha256:crypto.createHash('sha256').update(bytes).digest('hex')});
  }
}
const coverHTML='<section class="book-cover"><div class="eyebrow">中文教学精读 · NEURIPS 2025</div><h1>因果区分概念<br>从推导到实跑</h1><p>Causal Differentiating Concepts: Interpreting LM Behavior via Causal Representation Learning</p><p class="cover-meta">Navita Goyal、Hal Daumé III、Alexandre Drouin、Dhanya Sridhar<br>NeurIPS 2025正式版，29页；正文、附录A–C、公式(1)–(5)、全部原图与表。</p><p class="cover-meta">含基础补课、逐式推导、证明核查、中英词典与63次独立实跑。<br>未取得作者代码；新增计算不是官方代码复现，大型LLM/SAE原实验未执行。<br>作者报告、条件化结论、教学诊断与本地实跑分别标记；非作者正式勘误。</p></section>';
const book={title:'CDC因果区分概念中文精读',version:'NeurIPS 2025正式版',coverHTML,glossary,media,chapters};
fs.writeFileSync(path.join(root,'book-data.js'),'window.STUDY_BOOK='+JSON.stringify(book)+';\n');
const katex=require('./assets/katex.min.js'),marked=require('./assets/marked.umd.js'),renderer=require('./assets/render-core.js');
const mathReport=chapters.map(c=>({chapter:c.file,...renderer.render(c.markdown,marked,katex,media),html:undefined}));
fs.writeFileSync(path.join(out,'math_render_report.json'),JSON.stringify(mathReport,null,2));
fs.writeFileSync(path.join(out,'figure_inventory.json'),JSON.stringify(images,null,2));
const equations=JSON.parse(fs.readFileSync(path.join(root,'source','equations.json'),'utf8'));
for(const e of equations)katex.renderToString(e.latex,{throwOnError:true,displayMode:true,strict:'ignore'});
fs.writeFileSync(path.join(out,'equation_inventory.json'),JSON.stringify(equations,null,2));
const summary={chapters:chapters.length,characters:chapters.reduce((s,c)=>s+c.markdown.length,0),glossaryTerms:glossary.length,uniqueImages:Object.keys(media).length,figureReferences:images.length,numberedEquations:equations.length,guideFormulas:mathReport.reduce((s,r)=>s+r.formulas,0),mathErrors:mathReport.flatMap(r=>r.errors).length};
if(summary.mathErrors){console.error(JSON.stringify(mathReport.filter(r=>r.errors.length),null,2));throw new Error('Math rendering failed');}
function standalone(input,output){
  let html=fs.readFileSync(path.join(root,input),'utf8');
  html=html.replace(/<link rel="stylesheet" href="([^"]+)">/g,(_,file)=>'<style>\n'+fs.readFileSync(path.join(root,file),'utf8')+'\n</style>');
  const scripts=[];html=html.replace(/<script defer src="([^"]+)"><\/script>/g,(_,file)=>{scripts.push(fs.readFileSync(path.join(root,file),'utf8'));return '';});
  html=html.replace('</body>',()=>'<script>\n'+scripts.join('\n;\n').replace(/<\/script/gi,'<\\/script')+'\n</script>\n</body>');
  if(input==='index.html')html=html.replaceAll('href="lab.html"','href="交互实验室_离线单文件.html"').replaceAll('(lab.html)','(交互实验室_离线单文件.html)');
  else html=html.replaceAll('href="index.html#','href="中文精读_离线单文件.html#');
  fs.writeFileSync(path.join(root,output),html);
}
standalone('index.html','中文精读_离线单文件.html');standalone('lab.html','交互实验室_离线单文件.html');
// The generated chapter links also need to work from the standalone reader.
const single=path.join(root,'中文精读_离线单文件.html');
fs.writeFileSync(single,fs.readFileSync(single,'utf8').replaceAll('href=\\"lab.html\\"','href=\\"交互实验室_离线单文件.html\\"'));
fs.writeFileSync(path.join(out,'build_summary.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
