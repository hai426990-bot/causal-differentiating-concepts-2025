(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.StudyGlossary = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const escapeRegex = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function index(entries) {
    const aliases = new Map();
    const byID = new Map();
    for (const entry of entries) {
      byID.set(entry.id, entry);
      for (const alias of [entry.name, ...entry.aliases]) {
        const key = alias.toLowerCase();
        if (key.length >= 2 && !aliases.has(key)) aliases.set(key, entry);
      }
    }
    const pattern = [...aliases.keys()].sort((a, b) => b.length - a.length).map(escapeRegex).join('|');
    return { aliases, byID, pattern };
  }
  function matches(text, data) {
    if (!data.pattern) return [];
    const regex = new RegExp(data.pattern, 'gi');
    const result = [];
    for (const match of text.matchAll(regex)) {
      const value = match[0];
      if (/^[a-z0-9 _-]+$/i.test(value)) {
        const before = text[match.index - 1] || '', after = text[match.index + value.length] || '';
        if (/[a-z0-9_]/i.test(before) || /[a-z0-9_]/i.test(after)) continue;
      }
      result.push({ start: match.index, end: match.index + value.length, text: value, entry: data.aliases.get(value.toLowerCase()) });
    }
    return result;
  }
  function find(entries, query) {
    const q = query.trim().toLowerCase();
    if (!q) return entries.slice();
    return entries.map((entry, order) => {
      const keys = [entry.name, ...entry.aliases].map(s => s.toLowerCase());
      const body = [entry.intuition, entry.definition, entry.example, entry.paper, entry.warning].join(' ').toLowerCase();
      const score = keys.includes(q) ? 0 : keys.some(s => s.startsWith(q)) ? 1 : keys.some(s => s.includes(q)) ? 2 : body.includes(q) ? 3 : 4;
      return { entry, score, order };
    }).filter(r => r.score < 4).sort((a, b) => a.score - b.score || a.order - b.order).map(r => r.entry);
  }
  return { index, matches, find };
});
