(function () {
  'use strict';
  const book = window.STUDY_BOOK;
  const content = document.getElementById('content');
  const sidebar = document.querySelector('.sidebar');
  const storageKey = 'study-cdc-neurips2025-v1';
  let state = { current: book.chapters[0].id, read: {}, font: 18 };
  try { state = { ...state, ...JSON.parse(localStorage.getItem(storageKey) || '{}') }; } catch (_) { /* local files may disallow storage */ }
  let currentIndex = 0, all = false;
  const cache = new Map();
  const terms = book.glossary || [];
  const termIndex = StudyGlossary.index(terms);
  const termCache = new Map();
  let selectedTerm = terms[0]?.id;
  function save() { try { localStorage.setItem(storageKey, JSON.stringify(state)); } catch (_) {} }
  function rendered(chapter) {
    if (!cache.has(chapter.id)) {
      const result = StudyRender.render(chapter.markdown, marked, katex, book.media);
      result.html = result.html.replace(/href="((?:chapters\/)?([^/"#]+)\.md)(?:#[^"]*)?"/g, (original, file, id) => book.chapters.some(c => c.id === id) ? `href="#${id}"` : original);
      cache.set(chapter.id, result);
    }
    return cache.get(chapter.id);
  }
  function updateNav() {
    document.getElementById('chapters').innerHTML = book.chapters.map((c, i) => `<a class="chapter-link ${!all && i === currentIndex ? 'active' : ''} ${state.read[c.id] ? 'read' : ''}" href="#${c.id}"><span class="number">${c.id === '00_basics' ? '先修' : c.id === '14_glossary' ? '词典' : c.id.slice(0, 2)}</span><span>${StudyRender.escapeHTML(c.title.replace(/^(?:\d+|先修|词典)｜/, ''))}</span></a>`).join('');
    document.getElementById('previous').disabled = all || currentIndex === 0;
    document.getElementById('next').disabled = all || currentIndex === book.chapters.length - 1;
    document.getElementById('mark-read').disabled = all;
    document.getElementById('mark-read').textContent = state.read[book.chapters[currentIndex].id] ? '✓ 已读（点击取消）' : '标记本章已读';
  }
  function route() {
    const [id, anchor] = decodeURIComponent(location.hash.slice(1)).split('~');
    all = id === 'all' || new URLSearchParams(location.search).has('all');
    const index = book.chapters.findIndex(c => c.id === (id || state.current));
    currentIndex = index < 0 ? 0 : index;
    if (!all) { state.current = book.chapters[currentIndex].id; save(); }
    const selected = all ? book.chapters : [book.chapters[currentIndex]];
    let formulas = 0, errors = 0;
    const cover = all ? book.coverHTML : '';
    content.innerHTML = cover + selected.map(c => { const r = rendered(c); formulas += r.formulas; errors += r.errors.length; return `<article id="${c.id}">${r.html}</article>`; }).join('');
    for (const figure of content.querySelectorAll('figure.study-figure')) {
      const image = figure.querySelector('img');
      if (!image) continue;
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'figure-zoom-trigger';
      button.setAttribute('aria-label', '放大查看：' + image.alt);
      image.before(button); button.append(image);
      const hint = document.createElement('span'); hint.className = 'figure-hint'; hint.textContent = '点击图片放大查看';
      button.after(hint);
      button.onclick = () => openFigure(image, figure.querySelector('figcaption')?.textContent || image.alt);
    }
    for (const article of content.querySelectorAll('article')) {
      const headings = [...article.querySelectorAll('h2')];
      headings.forEach((h, i) => { if (!h.id) h.id = `${article.id}-section-${i}`; });
      if (!all && headings.length) {
        const nav = document.createElement('details'); nav.className = 'toc-inline';
        nav.innerHTML = '<summary>本章小节</summary>' + headings.map(h => `<a href="#${article.id}~${h.id}">${StudyRender.escapeHTML(h.textContent)}</a>`).join('');
        article.querySelector('h1').after(nav);
      }
      if (article.id !== '14_glossary') annotateTerms(article);
    }
    document.documentElement.style.setProperty('--font-size', state.font + 'px');
    document.getElementById('breadcrumb').textContent = all ? '全书阅读 · 含基础补课与术语词典 · 可打印' : `第 ${currentIndex + 1} / ${book.chapters.length} 节 · ${book.version}`;
    document.getElementById('all-book').textContent = all ? '分章阅读' : '全书';
    document.title = (all ? 'CDC完整中文精读手册' : book.chapters[currentIndex].title) + '｜NeurIPS 2025';
    updateNav(); sidebar.classList.remove('open'); document.getElementById('menu').setAttribute('aria-expanded', 'false');
    document.getElementById('glossary-stat').textContent = terms.length + '个基础词条';
    document.getElementById('figure-stat').textContent = Object.keys(book.media || {}).length + '幅图';
    window.STUDY_TEST = { chapters: book.chapters.length, current: book.chapters[currentIndex].id, all, formulas, mathErrors: errors, glossaryTerms: terms.length, termLinks: content.querySelectorAll('.term-link').length, figures: content.querySelectorAll('figure.study-figure').length, embeddedImages: [...content.querySelectorAll('img')].filter(img => img.getAttribute('src').startsWith('data:image/')).length, ready: true };
    document.body.dataset.rendered = 'true';
    if (anchor && document.getElementById(anchor)) document.getElementById(anchor).scrollIntoView();
    else window.scrollTo(0, 0);
  }
  document.addEventListener('click', event => {
    const a = event.target.closest('a'); if (!a) return;
    const href = a.getAttribute('href') || '';
    const match = href.match(/^(?:chapters\/)?([^/]+)\.md(?:#(.*))?$/);
    if (match && book.chapters.some(c => c.file === match[1] + '.md')) { event.preventDefault(); location.hash = match[1] + (match[2] ? '~' + match[2] : ''); }
  });
  document.getElementById('previous').onclick = () => { location.hash = book.chapters[Math.max(0, currentIndex - 1)].id; };
  document.getElementById('next').onclick = () => { location.hash = book.chapters[Math.min(book.chapters.length - 1, currentIndex + 1)].id; };
  document.getElementById('mark-read').onclick = () => { const id = book.chapters[currentIndex].id; state.read[id] = !state.read[id]; save(); updateNav(); };
  document.getElementById('menu').onclick = () => { const open = sidebar.classList.toggle('open'); document.getElementById('menu').setAttribute('aria-expanded', String(open)); };
  document.getElementById('smaller').onclick = () => { state.font = Math.max(14, state.font - 1); document.documentElement.style.setProperty('--font-size', state.font + 'px'); save(); };
  document.getElementById('larger').onclick = () => { state.font = Math.min(24, state.font + 1); document.documentElement.style.setProperty('--font-size', state.font + 'px'); save(); };
  document.getElementById('all-book').onclick = () => { location.href = location.pathname + (all ? '#' + state.current : '#all'); };
  document.getElementById('print').onclick = () => window.print();
  const figureDialog = document.getElementById('figure-dialog');
  const figureImage = document.getElementById('figure-full');
  const figureViewer = document.getElementById('figure-viewer');
  let figureWidth = 1000, figureScale = 1;
  function fitFigure() {
    figureScale = 1;
    figureViewer.classList.remove('zoomed');
    figureImage.style.width = '';
    document.getElementById('figure-zoom-level').textContent = '适应窗口';
    figureViewer.scrollTo(0, 0);
  }
  function openFigure(image, caption) {
    figureImage.src = image.src; figureImage.alt = image.alt;
    figureWidth = Number(image.getAttribute('width')) || image.naturalWidth || 1000;
    document.getElementById('figure-caption').textContent = caption;
    fitFigure(); figureDialog.showModal();
  }
  document.getElementById('figure-close').onclick = () => figureDialog.close();
  document.getElementById('figure-fit').onclick = fitFigure;
  document.getElementById('figure-zoom-in').onclick = () => {
    figureScale = Math.min(3, figureScale + 0.5);
    figureViewer.classList.add('zoomed');
    figureImage.style.width = Math.round(figureWidth * figureScale) + 'px';
    document.getElementById('figure-zoom-level').textContent = Math.round(figureScale * 100) + '%';
  };
  figureDialog.addEventListener('close', () => figureImage.removeAttribute('src'));
  const termDialog = document.getElementById('term-dialog');
  const termInput = document.getElementById('term-input');
  const termList = document.getElementById('term-list');
  const termDetail = document.getElementById('term-detail');
  function annotateTerms(article) {
    const walker = document.createTreeWalker(article, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.parentElement.closest('.katex,code,pre,a,button,summary,h1,h2,h3,h4,h5,h6,figcaption,.toc-inline,script,style')) continue;
      if (node.textContent.trim()) nodes.push(node);
    }
    const seen = new Set();
    for (const node of nodes) {
      const hits = StudyGlossary.matches(node.textContent, termIndex).filter(hit => {
        if (seen.has(hit.entry.id)) return false;
        seen.add(hit.entry.id); return true;
      });
      if (!hits.length) continue;
      const fragment = document.createDocumentFragment(); let cursor = 0;
      for (const hit of hits) {
        fragment.append(document.createTextNode(node.textContent.slice(cursor, hit.start)));
        const button = document.createElement('button'); button.type = 'button'; button.className = 'term-link';
        button.textContent = hit.text; button.dataset.termId = hit.entry.id;
        button.title = '点击查看：' + hit.entry.name;
        button.setAttribute('aria-label', '查看“' + hit.entry.name + '”的基础解释');
        button.onclick = () => openTerm(hit.entry.id);
        fragment.append(button); cursor = hit.end;
      }
      fragment.append(document.createTextNode(node.textContent.slice(cursor))); node.replaceWith(fragment);
    }
  }
  function selectTerm(entry) {
    selectedTerm = entry.id;
    if (!termCache.has(entry.id)) {
      const markdown = `## ${entry.name}\n\n**${entry.group}** · ${entry.english}\n\n### 先抓直觉\n\n${entry.intuition}\n\n### 定义\n\n${entry.definition}\n\n### 算一个例子\n\n${entry.example}\n\n### 论文为什么需要它\n\n${entry.paper}\n\n> **别混淆：** ${entry.warning}`;
      termCache.set(entry.id, StudyRender.render(markdown, marked, katex).html);
    }
    termDetail.innerHTML = termCache.get(entry.id); termDetail.scrollTop = 0;
    for (const button of termList.querySelectorAll('button')) button.classList.toggle('active', button.dataset.termId === entry.id);
    document.getElementById('term-full').disabled = false;
  }
  function filterTerms() {
    const found = StudyGlossary.find(terms, termInput.value); termList.replaceChildren();
    for (const entry of found) {
      const button = document.createElement('button'); button.type = 'button'; button.dataset.termId = entry.id;
      const title = document.createElement('strong'); title.textContent = entry.name;
      const group = document.createElement('span'); group.textContent = entry.group;
      button.append(title, group); button.onclick = () => selectTerm(entry); termList.append(button);
    }
    if (!found.length) {
      termList.textContent = '没有找到，可以换一个中文或英文关键词。';
      termDetail.textContent = '例如输入“密度”“独立”“逆映射”或“logit”。';
      document.getElementById('term-full').disabled = true; return;
    }
    selectTerm(found.find(entry => entry.id === selectedTerm) || found[0]);
  }
  function openTerm(id) {
    selectedTerm = id || selectedTerm || terms[0]?.id;
    termInput.value = ''; filterTerms();
    if (!termDialog.open) termDialog.showModal();
  }
  document.getElementById('glossary-open').onclick = () => openTerm();
  document.getElementById('term-close').onclick = () => termDialog.close();
  termInput.oninput = filterTerms;
  document.getElementById('term-full').onclick = () => { termDialog.close(); location.hash = '14_glossary~term-' + selectedTerm; };
  document.getElementById('term-basics').onclick = () => termDialog.close();
  let closedDetails = [], scaledMath = [];
  window.addEventListener('beforeprint', () => {
    closedDetails = [...content.querySelectorAll('details:not([open])')];
    closedDetails.forEach(d => d.open = true);
    scaledMath = [];
    for (const display of content.querySelectorAll('.katex-display')) {
      const visual = display.querySelector('.katex-html');
      if (!visual || display.clientWidth < 1) continue;
      const width = visual.getBoundingClientRect().width;
      if (width > display.clientWidth) {
        scaledMath.push([display, display.style.fontSize]);
        display.style.fontSize = (parseFloat(getComputedStyle(display).fontSize) * display.clientWidth / width * 0.97) + 'px';
      }
    }
  });
  window.addEventListener('afterprint', () => {
    closedDetails.forEach(d => d.open = false);
    scaledMath.forEach(([display, size]) => display.style.fontSize = size);
  });
  const dialog = document.getElementById('search-dialog');
  const input = document.getElementById('search-input');
  function openSearch() { dialog.showModal(); input.focus(); }
  document.getElementById('search-open').onclick = openSearch;
  document.getElementById('search-close').onclick = () => dialog.close();
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); if (!dialog.open) openSearch(); } });
  input.oninput = () => {
    const query = input.value.trim().toLowerCase();
    const holder = document.getElementById('search-results'); holder.replaceChildren();
    if (!query) { holder.textContent = '支持全文检索中文、公式编号和变量名。'; return; }
    for (const c of book.chapters) {
      const position = c.markdown.toLowerCase().indexOf(query); if (position < 0) continue;
      const button = document.createElement('button'); button.className = 'search-result';
      const title = document.createElement('strong'); title.textContent = c.title;
      const snippet = document.createElement('span'); snippet.textContent = '…' + c.markdown.slice(Math.max(0, position - 40), position + 100).replace(/[$#*`]/g, '') + '…';
      button.append(title, snippet); button.onclick = () => { dialog.close(); if (location.hash === '#' + c.id) route(); else location.hash = c.id; };
      holder.append(button);
    }
    if (!holder.children.length) holder.textContent = '未找到。可以换用“log-odds”“单稀疏”“实跑”等关键词。';
  };
  window.addEventListener('hashchange', route);
  route();
})();
