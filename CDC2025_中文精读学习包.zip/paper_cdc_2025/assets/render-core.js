(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.StudyRender = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function escapeHTML(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function tokenize(markdown) {
    const code = [];
    let text = markdown.replace(/```[^\n]*\n[\s\S]*?```/g, s => `STUDYCODE${code.push(s) - 1}END`);
    text = text.replace(/`[^`\n]+`/g, s => `STUDYCODE${code.push(s) - 1}END`);
    const math = [];
    text = text.replace(/\$\$([\s\S]+?)\$\$|\$([^$\n]+?)\$/g, (_, block, inline) => {
      math.push({ tex: block !== undefined ? block.trim() : inline.trim(), display: block !== undefined });
      return `STUDYMATH${math.length - 1}END`;
    });
    text = text.replace(/STUDYCODE(\d+)END/g, (_, i) => code[Number(i)]);
    return { text, math };
  }
  function render(markdown, marked, katex, media = {}) {
    const data = tokenize(markdown);
    let html = marked.parse(data.text, { gfm: true, breaks: false });
    const errors = [];
    html = html.replace(/STUDYMATH(\d+)END/g, (_, i) => {
      const item = data.math[Number(i)];
      try {
        return katex.renderToString(item.tex, {
          displayMode: item.display, throwOnError: true, strict: 'ignore', trust: false,
          macros: { '\\bm': '\\boldsymbol{#1}', '\\one': '\\boldsymbol{1}' }
        });
      } catch (e) {
        errors.push({ tex: item.tex, error: e.message });
        return `<span class="math-error">${escapeHTML(item.tex)}</span>`;
      }
    });
    html = html.replace(/(<img\b[^>]*\bsrc=")([^"]+)(")/g, (_, prefix, src, suffix) => {
      const image = media[src];
      return image ? `${prefix}${image.dataURI}${suffix} width="${image.width}" height="${image.height}"` : prefix + src + suffix;
    });
    return { html, errors, formulas: data.math.length };
  }
  return { tokenize, render, escapeHTML };
});
