(function(){
  'use strict';
  const $ = id => document.getElementById(id);
  const n = id => Number($(id).value);
  const f = (x, places=6) => Number(x).toFixed(places);
  function softmax(values){const m=Math.max(...values), e=values.map(v=>Math.exp(v-m)), s=e.reduce((a,b)=>a+b,0);return e.map(v=>v/s);}
  function dci(r){
    const row=r.map(x=>x.reduce((a,b)=>a+b,0)), col=[r[0][0]+r[1][0],r[0][1]+r[1][1]], total=row[0]+row[1];
    const entropy=p=>-p.reduce((s,v)=>s+(v>0?v*Math.log2(v):0),0);
    if(!total)return {D:0,C:0};
    let D=0,C=0;for(let i=0;i<2;i++)if(row[i])D+=row[i]/total*(1-entropy(r[i].map(v=>v/row[i])));
    for(let j=0;j<2;j++)if(col[j])C+=col[j]/total*(1-entropy([r[0][j]/col[j],r[1][j]/col[j]]));
    return {D,C};
  }
  function rotation(degrees){
    const t=degrees*Math.PI/180, points=[[-1,-1],[-1,1],[1,-1],[1,1]].map(([x,y])=>[x*Math.cos(t)-y*Math.sin(t),x*Math.sin(t)+y*Math.cos(t)]);
    const costs=[],differences=[];for(let i=0;i<4;i++)for(let j=i+1;j<4;j++){const d=[points[j][0]-points[i][0],points[j][1]-points[i][1]];differences.push(d);costs.push([d[1]**2,d[0]**2]);}
    let best=Infinity,axes=null;for(let mask=1;mask<63;mask++){const a=costs.map((_,i)=>(mask>>i)&1);const value=costs.reduce((s,c,i)=>s+c[a[i]],0);if(value<best){best=value;axes=a;}}
    const loss=costs.map((c,i)=>c[axes[i]]);return {points,costs,loss,axes,sum:best,zero:loss.filter(v=>v<1e-10).length};
  }
  function updateSoft(){
    const a=n('logit'),b=n('offset'),before=softmax([0,a,-1]),after=softmax([b,a+b,-1+b]);
    $('logit-value').textContent=f(a,1);$('offset-value').textContent=f(b,1);
    $('soft-bars').innerHTML=after.map((p,i)=>`<div class="bar-row"><span>类别${i}</span><div class="bar-track"><div class="bar" style="width:${100*p}%"></div></div><strong>${f(p,4)}</strong></div>`).join('');
    $('soft-result').textContent=`原概率 = (${before.map(v=>f(v)).join(', ')})\n加 b 后 = (${after.map(v=>f(v)).join(', ')})\n最大概率差 = ${Math.max(...before.map((p,i)=>Math.abs(p-after[i]))).toExponential(2)}\nlog[p(1)/p(0)] = ${f(Math.log(after[1]/after[0]))} = a`;
  }
  function updateRotation(){
    const degree=n('angle'),r=rotation(degree);$('angle-value').textContent=f(degree,1)+'°';
    const svg=$('rotation-svg'),scale=80,cx=210,cy=170;
    svg.innerHTML='<path d="M30 170H390 M210 20V320" stroke="#a4b7b1" stroke-width="1.5"/>'+r.points.map(([x,y],i)=>`<circle cx="${cx+x*scale}" cy="${cy-y*scale}" r="7" fill="${['#187d78','#b58028','#7069a2','#cb6f67'][i]}"/><text x="${cx+x*scale+10}" y="${cy-y*scale-8}" font-size="15" fill="#29414a">C${i+1}</text>`).join('');
    $('rotation-result').textContent=`6个组对残差 = [${r.loss.map(v=>f(v,4)).join(', ')}]\n残差平方和 = ${f(r.sum)}\n零残差组对 = ${r.zero} / 6\n选中轴 = [${r.axes.map(a=>a+1).join(', ')}]，覆盖二维\n精确公式值 = ${f(16-8*Math.cos(2*degree*Math.PI/180)-8*Math.sin(2*degree*Math.PI/180))}`;
  }
  function updateScale(){const e=10**n('scale');$('scale-value').textContent='ε='+f(e,4);$('scale-result').textContent=`原分数 wᵀz = 2×1 − 1×2 = 0\n缩放后分数 (w/ε)ᵀ(εz) = ${f((2/e)*e-(1/e)*(2*e))}\n原平方残差 = 3²+4² = 25\n缩放后平方残差 = ${f(25*e*e,8)}\n损失比 = ε² = ${f(e*e,8)}`;}
  function updateDCI(){const r=[[n('r00'),n('r01')],[n('r10'),n('r11')]].map(row=>row.map(v=>Number.isFinite(v)?Math.max(0,v):0));const value=dci(r);$('dci-result').textContent=`D（特征专一性） = ${f(value.D)}\nC（因素集中度） = ${f(value.C)}\nI（测试因素预测） = 未提供，不能由R单独计算\n总重要性 = ${f(r.flat().reduce((a,b)=>a+b,0),3)}`;}
  const formulas={'soft-formula':String.raw`p_c=\frac{e^{\ell_c+b}}{\sum_j e^{\ell_j+b}}=\frac{e^{\ell_c}}{\sum_j e^{\ell_j}}`,'rotation-formula':String.raw`L(\theta)=16-8\cos(2\theta)-8\sin(2\theta)`,'scale-formula':String.raw`\|\epsilon v\|^2=\epsilon^2\|v\|^2`};
  let errors=0;for(const [id,tex]of Object.entries(formulas)){try{$(id).innerHTML=katex.renderToString(tex,{displayMode:true,throwOnError:true});}catch(e){errors++;$(id).textContent=tex;}}
  for(const id of ['logit','offset'])$(id).oninput=updateSoft;$('angle').oninput=updateRotation;$('scale').oninput=updateScale;
  for(const id of ['r00','r01','r10','r11'])$(id).oninput=updateDCI;
  for(const [id,r]of Object.entries({aligned:[1,0,0,1],mixed:[1,1,1,1],eighty:[.8,.2,.2,.8],duplicate:[1,0,1,0]}))$(id).onclick=()=>{['r00','r01','r10','r11'].forEach((key,i)=>$(key).value=r[i]);updateDCI();};
  updateSoft();updateRotation();updateScale();updateDCI();
  window.LAB_MATH={softmax,dci,rotation};window.LAB_TEST={ready:true,panels:4,mathErrors:errors,rotation22:rotation(22.5).sum,dci80:dci([[.8,.2],[.2,.8]])};
})();
