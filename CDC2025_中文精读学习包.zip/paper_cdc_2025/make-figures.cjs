const fs = require('node:fs');
const path = require('node:path');
const out = path.join(__dirname, 'assets', 'figures');
fs.mkdirSync(out, { recursive: true });
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
const text = (x, y, s, cls = '') => `<text x="${x}" y="${y}" class="${cls}">${esc(s)}</text>`;
const line = (x, y, xx, yy, color = '#64748b', arrow = false) => `<path d="M${x},${y} L${xx},${yy}" fill="none" stroke="${color}" stroke-width="2.5"${arrow ? ' marker-end="url(#arrow)"' : ''}/>`;
const box = (x, y, w, h, title, detail, fill = '#e7f4f0') => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="12" fill="${fill}" stroke="#b3c6c4"/>${text(x+w/2,y+33,title,'center bold')}${text(x+w/2,y+61,detail,'center small')}`;
function svg(name, title, subtitle, body, width=1000, height=330) {
  const source = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(title)}"><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8" fill="#64748b"/></marker></defs><style>text{font-family:'Microsoft YaHei','Noto Sans CJK SC',sans-serif;font-size:21px;fill:#1d353e}.title{font-size:27px;font-weight:700}.small{font-size:17px}.center{text-anchor:middle}.bold{font-weight:700}.note{fill:#74634b;font-size:17px}</style><rect width="100%" height="100%" rx="18" fill="#fbfcf9"/>${text(35,44,title,'title')}${text(35,77,subtitle,'small')}${body}</svg>`;
  fs.writeFileSync(path.join(out, name+'.svg'), source);
}
svg('teaching_pipeline','把训练可见量与概念真值分开','教学流程图；箭头表示分析流程，不是恢复出的因果图',
  box(30,120,170,90,'文本 x','实际输入')+line(200,165,235,165,'#64748b',true)+box(240,120,185,90,'激活 g(x)','预训练/冻结编码器')+line(425,165,460,165,'#64748b',true)+box(465,120,210,90,'学习特征 ẑ','τ(g(x))，低维瓶颈')+line(675,165,710,165,'#64748b',true)+box(715,120,245,90,'行为预测 ĉ','线性logits + softmax')+
  text(35,260,'行为组 c：训练监督信号；真实因素 z：仅在可控实验中用于评价。','small')+text(35,293,'能预测 c ≠ 每个学习轴已对应一个真实概念。','note'));
svg('teaching_equivalence','信息没有丢，不代表坐标语义已经固定','旋转后的表征可以通过逆变换继续作出相同预测',
  box(45,116,225,100,'真实概念 z','职业 / 性别')+line(270,165,360,165,'#64748b',true)+text(296,145,'A','bold')+box(365,116,260,100,'混合表征 Az','两个轴都混合因素')+line(625,165,715,165,'#64748b',true)+text(648,145,'A⁻¹','bold')+box(720,116,235,100,'相同分类信息','预测头补偿混合')+
  text(48,267,'交叉熵约束预测概率；额外结构信号才可能缩小坐标等价类。','small')+text(48,299,'尺度、符号、置换通常仍然不确定；差分也不能确定统一平移。','note'));
svg('teaching_intervention','高层换位不等于观测数据已有纯配对','这是推论1需要可实现性条件的教学诊断，不是全定理反例',
  box(45,115,220,100,'观测 A：(0,0)','只替换第一坐标')+line(265,165,375,165,'#64748b',true)+box(380,115,245,100,'反事实：(1,0)','可在高层模型计算')+line(625,165,720,165,'#64748b',true)+box(725,115,230,100,'是否有输入 x？','需要另行确认','#fff1dd')+
  text(48,270,'观测 C 是 (1,2)，与 A 同时差两维；干预成功不使它自动变成 (1,0)。','small')+text(48,300,'在数据中搜索样本对，必须关心干预后的状态是否落在观测支撑。','note'));
svg('teaching_rank','四个类别，也可能只提供一个概念方向','类别数量足够是必要数量条件，不是权重差满秩',
  line(80,240,315,240)+line(80,240,80,105)+line(80,240,135,185,'#187d78',true)+line(80,240,190,130,'#187d78',true)+line(80,240,220,100,'#187d78',true)+text(105,285,'多条平行权重：秩 1','small')+
  line(420,240,655,240)+line(420,240,420,105)+line(420,240,600,240,'#187d78',true)+line(420,240,420,120,'#c18a2b',true)+text(435,285,'独立方向覆盖平面：秩 2','small')+
  text(715,145,'m > d 不能推出满秩','bold')+text(715,185,'看类别参考权重差','small')+text(715,220,'还需真实支撑满维','small'));
svg('teaching_chain','不要把一个可靠引理当成整条证明已闭合','绿色：可在明确条件下证明；橙色：需要额外桥梁',
  box(25,115,215,100,'预测概率正确','总体最优 / 可实现')+line(240,165,268,165,'#64748b',true)+box(275,115,205,100,'仿射关系','log-odds满秩')+line(480,165,508,165,'#64748b',true)+box(515,115,215,100,'找对真实纯配对','支撑、未知配对选择','#fff1dd')+line(730,165,758,165,'#64748b',true)+box(765,115,210,100,'尺度 + 置换','同配对单稀疏列')+
  text(35,270,'非零残差大小、尺度退化、配对可实现性，都不能只用“匹配数量”代替。','small')+text(35,302,'原文陈述、条件化证明、有限数值诊断分别标记。','note'));
svg('teaching_metrics','三个评价问题，不是一回事','R的行是学习特征；列是真实因素',
  box(40,115,280,115,'D：特征是否专一','按行看：一轴是否混多因素')+box(360,115,280,115,'C：因素是否集中','按列看：一因素是否散多轴')+box(680,115,280,115,'I：因素能否预测','看全部特征的测试预测')+
  text(45,282,'可逆旋转可以保持信息性 I，却降低逐轴的 D / C / MCC。','small')+text(45,312,'监督指标需要真实因素标签；真实拒答案例不能直接计算同样的真值分数。','note'));
console.log('6 deterministic teaching diagrams generated.');
