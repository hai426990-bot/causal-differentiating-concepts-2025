计算证据包：63次独立实跑，非作者官方代码复现。

先读experiments/README.md；无需下载LM即可运行verify_results.py --refit重新拟合评价器及重算指标。
合成与文本首轮摘要用于同协议确定性对照，confirmed目录保存完整预测与模型。
不包含原始人物简介、完整LM、机器凭据或未经确认许可的完整论文。
