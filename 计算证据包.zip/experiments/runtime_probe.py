import os
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import time
t = time.perf_counter()
def note(label): print(f'{label}: {time.perf_counter()-t:.3f}s', flush=True)
note('start')
import numpy as np
note('numpy imported')
import torch
note('torch imported')
torch.set_num_threads(1)
note('thread count set')
from cdc_core import VAE
note('experiment module imported')
torch.manual_seed(990)
note('seed set')
model = VAE(6)
note('model initialized')
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
note('optimizer initialized')
batch = torch.randn(256, 6)
note('data ready')
for i in range(3):
    output, mu, lv = model(batch)
    loss = (output-batch).square().mean()+1e-3*(-0.5*(1+lv-mu.square()-lv.exp()).mean())
    note(f'forward {i}')
    opt.zero_grad(); loss.backward(); opt.step()
    note(f'update {i}')
print({'loss': float(loss.detach()), 'threads': torch.get_num_threads()}, flush=True)
