from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time

for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key, '1')
import numpy as np
import torch
from cdc_core import make_synthetic, split_indices, pretrain_vae, fit_alignment, sha256_array

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--n', type=int, default=20000)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--seeds', default='11,23,37')
    parser.add_argument('--cases', default='2:linear,2:sparse,2:dense,3:linear,3:sparse,3:dense')
    parser.add_argument('--output', default='results/synthetic')
    args = parser.parse_args()
    output = ROOT / args.output; output.mkdir(parents=True, exist_ok=True)
    protocol = {
        'kind': 'independent reimplementation with declared stabilizers; not official code reproduction',
        'n': args.n, 'epochs_vae': args.epochs, 'epochs_alignment': args.epochs,
        'seeds': [int(s) for s in args.seeds.split(',')], 'cases': args.cases.split(','),
        'split': 'stratified 70:15:15 by behavior', 'batch_size': 256,
        'mu': 0, 'sigma': 1, 'behavior_threshold': 0.6,
        'd3_behavior': 'four-region d2 behavior plus 4 * indicator(z2>0); independently specified extension',
        'mixing': 'all six functions exactly transcribed from Appendix B page 19',
        'normalization': 'training-only feature standardization; BatchNorm without affine parameters at bottleneck; raw std floor penalty',
        'objective': f'AE: reconstruction; Pred: reconstruction+CE; CDC: reconstruction+CE+0.2 contrast, same {args.epochs} epochs including {min(10, max(1, args.epochs//5))} warmup epochs',
        'contrast': 'squared Euclidean norm as in PDF equation 4; 12 sampled anchors and 5 donors per anchor; shared nonzero pair shifts; alternating exact all-axis cover',
        'unreported_choices': ['Gaussian parameters', 'exact group thresholds and d3 grouping', 'VAE bottleneck dimension 16 and KL weight 0.001', 'Adam lr=0.001, weight decay=0.0001', 'normalization and variance floor', 'constraint weight and warmup', 'DP all-axis cover and minimum shift amplitude 0.1', 'DCI evaluator hyperparameters'],
        'selection': 'best validation objective, no test-based tuning', 'metrics': 'test MCC via Hungarian matching; DCI via train-fitted GradientBoostingRegressor, I=mean test R2',
        'python': platform.python_version(), 'torch': torch.__version__, 'numpy': np.__version__,
        'device': 'cpu', 'threads': 1,
        'code_sha256': hashlib.sha256((ROOT/'experiments'/'cdc_core.py').read_bytes()).hexdigest()
    }
    (output/'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    all_results = []; started = time.perf_counter()
    for case in protocol['cases']:
        dimension, kind = case.split(':'); dimension = int(dimension)
        for seed in protocol['seeds']:
            case_dir = output / f'd{dimension}_{kind}_seed{seed}'; case_dir.mkdir(exist_ok=True)
            print(f'START {case} seed={seed}', flush=True)
            x, z, c = make_synthetic(args.n, dimension, kind, seed)
            split = split_indices(c, seed)
            np.savez_compressed(case_dir/'dataset.npz', x=x, true_z=z, behavior=c, train=split[0], validation=split[1], test=split[2])
            data_hashes = {'x': sha256_array(x), 'z': sha256_array(z), 'c': sha256_array(c), 'split_sizes': [len(s) for s in split]}
            start = time.perf_counter()
            g, targets, pretrace, preinfo = pretrain_vae(x, split, seed, args.epochs)
            (case_dir/'vae.json').write_text(json.dumps({'trace': pretrace, 'normalization': preinfo, 'elapsed_seconds': time.perf_counter()-start, 'data': data_hashes}, indent=2), encoding='utf-8')
            z_split = [z[i] for i in split]; c_split = [c[i] for i in split]
            for method in ('ae', 'pred', 'cdc'):
                start = time.perf_counter()
                scores, features, predictions, trace, details = fit_alignment(g, targets, z_split, c_split, dimension, seed, method, args.epochs, artifact_dir=case_dir/f'{method}_artifacts')
                record = {'case': case, 'dimension': dimension, 'mixing': kind, 'seed': seed, 'method': method, 'metrics': scores, 'diagnostics': details, 'elapsed_seconds': time.perf_counter()-start, 'data': data_hashes}
                (case_dir/f'{method}.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
                np.savez_compressed(case_dir/f'{method}_predictions.npz', sample_id=split[2], true_z=z_split[2], learned_z=features, behavior=c_split[2], predicted_behavior=predictions)
                with (case_dir/f'{method}_test.csv').open('w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f); writer.writerow(['sample_id', *[f'z{i}' for i in range(dimension)], *[f'learned{i}' for i in range(dimension)], 'behavior', 'predicted_behavior'])
                    for row in zip(split[2], z_split[2], features, c_split[2], predictions): writer.writerow([int(row[0]), *row[1].tolist(), *row[2].tolist(), int(row[3]), int(row[4])])
                with (case_dir/f'{method}_trace.csv').open('w', newline='', encoding='utf-8') as f:
                    writer = csv.DictWriter(f, fieldnames=list(trace[0])); writer.writeheader(); writer.writerows(trace)
                all_results.append(record)
                (output/'runs.json').write_text(json.dumps(all_results, indent=2), encoding='utf-8')
                brief = {key: round(scores[key], 4) for key in ('MCC', 'DCI_D', 'DCI_C', 'DCI_I')}
                print(f'DONE {case} seed={seed} method={method} {brief} seconds={record["elapsed_seconds"]:.1f}', flush=True)
    (output/'completed.json').write_text(json.dumps({'runs': len(all_results), 'elapsed_seconds': time.perf_counter()-started, 'protocol_sha256': hashlib.sha256((output/'protocol.json').read_bytes()).hexdigest()}, indent=2), encoding='utf-8')
    print(f'COMPLETE {len(all_results)} runs in {time.perf_counter()-started:.1f}s', flush=True)

if __name__ == '__main__': main()
