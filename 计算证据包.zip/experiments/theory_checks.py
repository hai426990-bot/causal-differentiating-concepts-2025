"""Exact algebra and bounded diagnostic calculations, NOT numerical proof of all theorems."""
import os
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key, '1')
import csv
import itertools
import json
from pathlib import Path
import math
import numpy as np
import sympy as sp
import torch
from cdc_core import axis_cover, entropy_scores, mixing

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'results'/'theory'; OUT.mkdir(parents=True, exist_ok=True)
checks = []
def check(name, fn):
    try: detail = fn(); checks.append({'name': name, 'passed': True, 'detail': detail})
    except Exception as exc: checks.append({'name': name, 'passed': False, 'error': str(exc)})

def rank_counterexample():
    z1, z2 = sp.symbols('z1 z2', real=True)
    true = sp.Matrix([z1, z2])
    learned = sp.Matrix([z1+z2, (z1-z2)**3])
    w = sp.Matrix([[0, 0], [1, 1], [2, 2], [3, 3]])
    q = sp.Matrix([[0, 0], [1, 0], [2, 0], [3, 0]])
    residual = sp.simplify(w*true-q*learned)
    assert residual == sp.zeros(4, 1)
    assert w.rank() == 1 and 4 > 2
    hessian = sp.hessian(learned[1], (z1, z2))
    assert hessian != sp.zeros(2, 2)
    return {'m': 4, 'd': 2, 'weight_rank': 1, 'learned': [str(v) for v in learned], 'logits_residual': str(residual), 'nonzero_hessian': str(hessian), 'scope': 'Counterexample to Assumption 1 alone implying affine recovery; not a full counterexample satisfying Assumption 2.'}
check('定理1：m>d并不保证权重差满秩，非仿射表示也可产生相同logits', rank_counterexample)

def log_odds():
    w = sp.Matrix([[1, 0], [0, 1], [1, 1]])
    a = sp.Matrix([[2, 1], [-1, 3]])
    q = w*a.inv()
    assert q.rank() == w.rank() == 2
    left_inverse = (q.T*q).inv()*q.T
    assert sp.simplify(left_inverse*w-a) == sp.zeros(2, 2)
    return {'rank': 2, 'A': str(a), 'recovered_A': str(sp.simplify(left_inverse*w)), 'scope': 'Valid linear algebra after log-odds remove the input-dependent softmax normalizer.'}
check('补全条件后，log-odds左逆恢复仿射坐标', log_odds)

def closure_counterexample():
    # M is defined on intervened states, but not every state is an observed input.
    observed = {'A': (0, 0), 'B': (0, 1), 'C': (1, 2)}
    def behavior(z): return 'C' if z[0] == 1 else ('B' if z[1] == 1 else 'A')
    def intervene(z, donor, subset): return tuple(donor[i] if i in subset else z[i] for i in range(2))
    assert behavior(intervene(observed['A'], observed['C'], {0})) == 'C'
    for subset in (set(), {1}):
        assert behavior(intervene(observed['A'], observed['C'], subset)) != 'C'
    assert sum(a != b for a, b in zip(observed['A'], observed['C'])) == 2
    assert behavior(intervene(observed['A'], observed['B'], {1})) == 'B'
    assert behavior(intervene(observed['A'], observed['B'], {0})) != 'B'
    return {'observed': observed, 'intervened_AC': intervene(observed['A'], observed['C'], {0}), 'observed_AC_changed_coordinates': 2, 'scope': 'Definition-2/Corollary-1 realizability gap; not a simultaneous counterexample to the entire stochastic model.'}
check('推论1：反事实可生成不等于观测输入中存在纯单坐标配对', closure_counterexample)

def permutation_lemma():
    matrices = []
    for permutation in itertools.permutations(range(3)):
        for scales in itertools.product((sp.Rational(-2), sp.Rational(1, 2), sp.Rational(3)), repeat=3):
            a = sp.zeros(3)
            for col, row in enumerate(permutation): a[row, col] = scales[col]
            assert a.det() != 0
            assert all(sum(a[row, col] != 0 for row in range(3)) == 1 for col in range(3))
            matrices.append(str(a))
    return {'exact_matrices_checked': len(matrices), 'general_argument': 'If each of d nonzero columns has one support index and A is invertible, two columns cannot share an index; the indices form a permutation. Enumeration illustrates, not proves, the arbitrary-d statement.'}
check('列单稀疏加满秩的结构引理：162个精确矩阵及一般论证', permutation_lemma)

def rotation_diagnostic():
    points = np.array(list(itertools.product((-1., 1.), repeat=2)))
    pairs = list(itertools.combinations(range(4), 2))
    records = []
    for theta in (0., np.pi/8, np.pi/4):
        a = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
        learned = points @ a.T
        diff = np.array([learned[j]-learned[i] for i, j in pairs])
        costs = (diff**2).sum(1, keepdims=True)-diff**2
        axes = axis_cover(costs)
        delta = np.zeros_like(diff); delta[np.arange(6), axes] = diff[np.arange(6), axes]
        values = costs[np.arange(6), axes]
        assert np.linalg.matrix_rank(delta) == 2
        assert np.allclose(np.cov(learned.T, bias=True), np.eye(2))
        # Any linear-head logits are unchanged after inverse rotation.
        teacher = points
        learner_head = teacher @ a.T
        assert np.allclose(points @ teacher.T, learned @ learner_head.T)
        records.append({'angle_degrees': float(np.degrees(theta)), 'sum_squared_residual': float(values.sum()), 'mean_squared_residual': float(values.mean()), 'zero_pairs': int((values < 1e-10).sum()), 'shift_rank': int(np.linalg.matrix_rank(delta)), 'feature_covariance': np.cov(learned.T, bias=True).tolist(), 'axes': axes.tolist(), 'per_pair_loss': values.tolist()})
    assert np.isclose(records[0]['sum_squared_residual'], 8)
    assert np.isclose(records[1]['sum_squared_residual'], float(16-8*sp.sqrt(2)))
    assert records[1]['sum_squared_residual'] < records[0]['sum_squared_residual']
    (OUT/'rotation_counterexample.json').write_text(json.dumps({'records': records, 'scope': 'Counterexample to counting zero-residual pairs implying smaller total squared loss. Deterministic four-corner groups; not claimed to satisfy the paper stochastic softmax assumption jointly.'}, indent=2), encoding='utf-8')
    return {'values': records, 'exact_entangled_loss': str(16-8*sp.sqrt(2)), 'scope': 'Same covariance, equal attainable classifier logits, full shift span; fewer zero pairs can nevertheless yield lower equation-4 squared loss.'}
check('配对计数不能代替平方损失：固定尺度下22.5度旋转损失更低', rotation_diagnostic)

def scale_diagnostic():
    rng = np.random.default_rng(481)
    z, q, delta = rng.normal(size=(20, 2)), rng.normal(size=(4, 2)), rng.normal(size=(20, 2))
    logits = z @ q.T; residual = z[1:]-z[:-1]-delta[1:]
    baseline = (residual**2).sum()
    records = []
    for eps in (1., .1, .01, .001):
        scaled = eps*z; qs = q/eps; ds = eps*delta
        assert np.allclose(scaled @ qs.T, logits)
        value = float(((scaled[1:]-scaled[:-1]-ds[1:])**2).sum())
        assert np.isclose(value, eps**2*baseline)
        records.append({'epsilon': eps, 'squared_loss': value, 'loss_ratio': value/baseline, 'logit_max_error': float(np.abs(scaled@qs.T-logits).max())})
    return records
check('尺度退化：预测不变，平方残差按epsilon平方缩小', scale_diagnostic)

def dp_matches_enumeration():
    rng = np.random.default_rng(41)
    largest = 0.
    for dimension, pairs in ((2, 4), (3, 5)):
        for _ in range(20):
            costs = rng.random((pairs, dimension))
            guess = axis_cover(costs)
            exact = min(sum(costs[i, a] for i, a in enumerate(axes)) for axes in itertools.product(range(dimension), repeat=pairs) if len(set(axes)) == dimension)
            error = abs(float(costs[np.arange(pairs), guess].sum())-exact)
            assert error < 1e-12; largest = max(largest, error)
    return {'matrices': 40, 'max_error': largest}
check('span覆盖的动态规划与穷举一致', dp_matches_enumeration)

def gradient_check():
    torch.manual_seed(7)
    difference = torch.randn(3, 4, 5, 2, dtype=torch.double, requires_grad=True)
    shift = torch.randn(3, 2, dtype=torch.double, requires_grad=True)
    def cost(diff, delta):
        residual = diff.square().sum(-1, keepdim=True)-2*diff*delta[:, None, None, :]+delta[:, None, None, :].square()
        return residual.min(dim=2).values.mean()
    assert torch.autograd.gradcheck(cost, (difference, shift), eps=1e-6, atol=1e-5, rtol=1e-3)
    return {'dtype': 'float64', 'finite_difference_eps': 1e-6, 'atol': 1e-5, 'ties': 'random continuous test avoids nondifferentiable argmin ties'}
check('内层最小平方残差梯度通过有限差分', gradient_check)

def metric_examples():
    aligned = entropy_scores(np.eye(2))
    mixed = entropy_scores(np.ones((2, 2)))
    intermediate = entropy_scores(np.array([[.8, .2], [.2, .8]]))
    assert np.allclose(aligned, (1, 1)) and np.allclose(mixed, (0, 0))
    exact = 1+0.8*math.log(0.8, 2)+0.2*math.log(0.2, 2)
    assert np.allclose(intermediate, (exact, exact))
    return {'aligned_D_C': aligned, 'mixed_D_C': mixed, '80_20_D_C': intermediate}
check('DCI熵指标的三个手算例子', metric_examples)

def published_mixings():
    z2 = np.array([[1., 2.]])
    assert np.allclose(mixing(z2, 'linear'), [[2, 10, 3, 4, 7, -1]])
    assert np.allclose(mixing(z2, 'dense'), [[2, 7, 2, 8, 4, 8]])
    z3 = np.array([[1., 2., 3.]])
    assert np.allclose(mixing(z3, 'linear'), [[2, 10, 9, 6, 7, -2, 14]])
    return {'six_functions_shapes': {f'd{d}_{k}': list(mixing(np.ones((2, d)), k).shape) for d in (2, 3) for k in ('linear', 'sparse', 'dense')}}
check('附录B混合函数的维度与整数例子', published_mixings)

def rank_and_gauge():
    z1, z2, a, b = sp.symbols('z1 z2 a b', real=True)
    logits = sp.Matrix([z1, z2, z1+z2])
    common = a*z1+b*z2
    for i in range(3):
        assert sp.simplify((logits[i]+common)-(logits[0]+common)-(logits[i]-logits[0])) == 0
    return {'class_count': 3, 'dimension': 2, 'scope': 'Softmax common-logit gauge cancels in class-reference differences, not by treating the normalizer as input-independent.'}
check('softmax公共logit规范自由度的精确消去', rank_and_gauge)

failed = [c for c in checks if not c['passed']]
report = {'passed': len(checks)-len(failed), 'total': len(checks), 'checks': checks, 'general_proof_warning': 'Passing finite checks does not establish a general theorem. Counterexamples have explicitly bounded scopes.'}
(OUT/'checks.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
if failed: raise SystemExit(1)
