import os
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key, '1')
import csv
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from cdc_core import split_indices, standardize, fit_alignment

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(); parser.add_argument('--output', default='results/text_confirmed'); args = parser.parse_args()
output = ROOT/args.output; output.mkdir(parents=True, exist_ok=True)
source = ROOT/'results'/'text_features'/'features.npz'
data = np.load(source)
g, z, c, rows = data['activations'], data['true_z'], data['behavior'], data['dataset_row']
protocol = {'kind': 'reduced independent semi-synthetic experiment', 'seeds': [11, 23, 37], 'n': len(g), 'epochs': 50, 'frozen_encoder': True, 'alignment_hidden': 64, 'learned_dimension': 2, 'split': '70:15:15 stratified by synthetic behavior', 'reconstruction_target': 'standardized frozen CLS activation, not generated text', 'selection': 'validation objective only; no true-factor validation grid search', 'metrics': 'DCI importance from train-only gradient boosting classifiers; I=mean held-out factor accuracy; MCC uses numeric gender/income codes', 'data_file_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'departures': ['2400 instead of 20000 biographies', 'six professions with explicitly fixed income grouping instead of salary quantiles', 'frozen CLS features and max length 96', '50 alignment-only epochs instead of 3 full model epochs', 'fixed architecture instead of oracle DCI hyperparameter grid search', 'same normalization and stabilized contrastive implementation as synthetic experiments']}
(output/'protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
records = []
for seed in protocol['seeds']:
    split = split_indices(c, seed)
    scaled, mean, std = standardize(g[split[0]], g[split[1]], g[split[2]])
    for method in ('ae', 'pred', 'cdc'):
        print(f'START real-text seed={seed} method={method}', flush=True)
        start = time.perf_counter()
        scores, features, predictions, trace, details = fit_alignment(scaled, scaled, [z[i] for i in split], [c[i] for i in split], 2, seed, method, epochs=50, hidden=64, categorical=True, artifact_dir=output/f'{method}_seed{seed}_artifacts')
        record = {'seed': seed, 'method': method, 'metrics': scores, 'diagnostics': details, 'elapsed_seconds': time.perf_counter()-start}
        records.append(record)
        (output/f'{method}_seed{seed}.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
        np.savez_compressed(output/f'{method}_seed{seed}_test.npz', dataset_row=rows[split[2]], true_z=z[split[2]], learned_z=features, behavior=c[split[2]], predicted_behavior=predictions)
        with (output/f'{method}_seed{seed}_trace.csv').open('w', newline='', encoding='utf-8') as file:
            writer = csv.DictWriter(file, fieldnames=list(trace[0])); writer.writeheader(); writer.writerows(trace)
        (output/'runs.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
        print(f'DONE real-text seed={seed} method={method} '+str({k: round(scores[k],4) for k in ('MCC','DCI_D','DCI_C','DCI_I')}), flush=True)
(output/'completed.json').write_text(json.dumps({'runs': len(records), 'raw_text_published': False}, indent=2), encoding='utf-8')
