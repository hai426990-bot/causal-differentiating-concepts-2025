# 计算协议（运行前登记）

本地条件：Windows、约16GiB RAM、10核CPU、AMD RX580约4GiB显存，无CUDA。不会自动购买云GPU或调用收费模型API。

## 证据等级

1. **原文报告**：从正式PDF抄录，保留表号/页码；没有原始预测就不能重新计算其显著性。
2. **独立重实现**：依据公式(3)(4)及附录B编写。未取得官方代码时，不称官方代码复现。
3. **缩小规模或替代实验**：具体列出样本量、模型、标签构造、归一化、超参数等与原文差异。
4. **精确代数/数值诊断**：用于验证恒等式、构造反例、检查梯度；不是一般定理的数值证明。

## 基本约束

- 固定随机种子，固定70:15:15划分，保存原始测试预测、真实因子、配置、日志与文件散列。
- 基线与方法使用相同数据和训练预算。超参数仅用训练/验证集选择，不按测试指标挑选。
- 不保证新实验重现作者的精确分数；失败与反常结果同样报告。
- 作者未披露的实现细节一律列为自行选定的约定，而非原文事实。
- 合成数据可公开；真实人物简介不复制到公开网页，只发布数据版本/索引、统计和可重新获取的脚本。

## 先复核，不必重新训练

推荐Python 3.11，实际依赖完整列表见`environment_freeze.txt`。建立独立虚拟环境，不修改系统Python：

```powershell
python -m venv .venv
.venv/Scripts/python -m pip install torch==2.6.0+cpu --index-url https://download.pytorch.org/whl/cpu
.venv/Scripts/python -m pip install -r experiments/requirements.txt
.venv/Scripts/python experiments/theory_checks.py
.venv/Scripts/python experiments/verify_results.py --refit
```

`verify_results.py`读取保存的训练表征、测试预测与重要性矩阵，重算所有指标和汇总；`--refit`还重新拟合63次因素评价器。无需下载LM或原始人物简介。脚本不从网络加载pickle/任意Python对象。

## 完整重训

```powershell
python experiments/run_synthetic.py --n 20000 --epochs 50 --seeds 11,23,37 --output results/synthetic_confirmed
python experiments/prepare_text.py --per-cell 200 --max-length 96 --batch-size 16 --cache ./model-cache
python experiments/run_text.py --output results/text_confirmed
python experiments/summarize.py
python experiments/verify_results.py --refit
```

如果希望保留已发布证据，先复制到新目录再重训，避免覆盖。原始模型/数据从固定提交下载，Parquet有SHA256校验，模型只使用safetensors且`trust_remote_code=False`。

## 实验差异与证据文件

- `results/synthetic_confirmed/protocol.json`：六种混合、分组约定、所有新增稳定措施、代码SHA256。
- `results/text_confirmed/protocol.json`：小规模文本的全部偏离。
- `results/text_features/manifest.json`：模型/数据固定提交、实际特征提取设置。
- `results/*_confirmed/*artifacts/`：安全格式检查点、全部划分低维表征、逐因素测试预测。
- `results/synthetic/`与`results/text/`：保留首轮汇总，用于确定性复跑对照。
- `results/summary.json`、`all_runs.csv`、`exploratory_tests.csv`：生成表和探索性统计。

相同轮次并不等于相同耗时；CDC有额外搜索计算。单线程是本机环境修正，超时烟雾测试与原因见`runtime_notes.md`。不根据正式测试指标搜索超参数。

保存的检查点是解释瓶颈、标准化层与预测/重构头，不是完整语言模型。合成VAE的轨迹、归一化与种子已保存，但没有另行归档VAE权重；从输入重新得到相同低层特征需按固定协议重训VAE。复核已发布指标只需保存的低维表征与因素预测，无需这一步。
