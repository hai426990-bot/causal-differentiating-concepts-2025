"""Generate every new results table and plot from saved calculations, not prose guesses."""
import os
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key, '1')
from pathlib import Path
import csv
import hashlib
import json
import math
import platform
import statistics
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'output'; OUT.mkdir(exist_ok=True)
FIG = ROOT/'assets'/'figures'; FIG.mkdir(parents=True, exist_ok=True)
font = Path('C:/Windows/Fonts/msyh.ttc')
if font.exists():
    font_manager.fontManager.addfont(str(font)); plt.rcParams['font.family'] = 'Microsoft YaHei'
plt.rcParams.update({'axes.unicode_minus': False, 'svg.fonttype': 'none', 'font.size': 11, 'axes.spines.top': False, 'axes.spines.right': False})
KEYS = ('MCC', 'DCI_D', 'DCI_C', 'DCI_I')
LABELS = {'ae': 'AE 重构', 'pred': 'Pred 预测', 'cdc': 'CDC 独立实现'}
COLORS = {'ae': '#64748b', 'pred': '#c18a2b', 'cdc': '#187d78'}

def choose(kind):
    confirmed = ROOT/'results'/f'{kind}_confirmed'
    return confirmed if (confirmed/'completed.json').exists() else ROOT/'results'/kind

SYN, TEXT = choose('synthetic'), choose('text')
syn = json.loads((SYN/'runs.json').read_text(encoding='utf-8'))
text = json.loads((TEXT/'runs.json').read_text(encoding='utf-8'))
assert len(syn) == 54 and len(text) == 9

def aggregate(records):
    result = {}
    for method in LABELS:
        runs = [r for r in records if r['method'] == method]
        result[method] = {k: {'mean': statistics.mean(r['metrics'][k] for r in runs), 'sd': statistics.stdev(r['metrics'][k] for r in runs), 'values': [r['metrics'][k] for r in runs]} for k in KEYS}
    return result

cases = list(dict.fromkeys(r['case'] for r in syn))
summary = {'synthetic': {c: aggregate([r for r in syn if r['case'] == c]) for c in cases}, 'text': aggregate(text), 'counts': {'synthetic_runs': 54, 'text_runs': 9, 'distinct_synthetic_datasets': 18, 'synthetic_n_per_dataset': 20000, 'text_n': 2400, 'seeds': [11, 23, 37]}, 'source': {'synthetic': str(SYN.relative_to(ROOT)).replace('\\', '/'), 'text': str(TEXT.relative_to(ROOT)).replace('\\', '/')}, 'uncertainty': 'sample SD across three prespecified runs, not standard error or confidence interval'}

# Exploratory paired t tests, with one declared Holm family: all seven settings x four metrics.
tests = []
for case in [*cases, 'text']:
    records = text if case == 'text' else [r for r in syn if r['case'] == case]
    for key in KEYS:
        differences = [next(r['metrics'][key] for r in records if r['seed'] == s and r['method'] == 'cdc')-next(r['metrics'][key] for r in records if r['seed'] == s and r['method'] == 'pred') for s in (11, 23, 37)]
        value = stats.ttest_1samp(differences, 0)
        tests.append({'setting': case, 'metric': key, 'n': 3, 'mean_difference_cdc_minus_pred': statistics.mean(differences), 'paired_differences': differences, 't': float(value.statistic), 'p_two_sided': float(value.pvalue)})
ordered = sorted(range(len(tests)), key=lambda i: tests[i]['p_two_sided']); previous = 0.
for rank, index in enumerate(ordered):
    adjusted = min(1., max(previous, (len(tests)-rank)*tests[index]['p_two_sided']))
    tests[index]['p_holm_28'] = adjusted; previous = adjusted
summary['exploratory_tests'] = tests
summary['test_warning'] = 'n=3; normality unverified; shared text data across runs; not strong population significance evidence; original paper p values not reproduced'
summary['runtime'] = {'synthetic_training_protocol_seconds': json.loads((SYN/'completed.json').read_text())['elapsed_seconds'], 'text_feature_seconds': json.loads((ROOT/'results'/'text_features'/'manifest.json').read_text())['elapsed_feature_seconds'], 'text_alignment_seconds_sum': sum(r['elapsed_seconds'] for r in text), 'timing_note': 'Measured wall time; concurrent runs and import/startup vary; not a hardware-normalized benchmark'}
verification_file=OUT/'results_verification.json'
if verification_file.exists():
    verification=json.loads(verification_file.read_text(encoding='utf-8'))
    if not verification['errors']:
        summary['verification']={key:verification[key] for key in ('passed_model_runs','numeric_entries_compared','maximum_absolute_difference','evaluator_refits')}
(ROOT/'results'/'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')

def fmt(value): return f'{value["mean"]:.3f} ± {value["sd"]:.3f}'
def table(agg):
    lines = ['|方法|MCC|D|C|I|', '|---|---:|---:|---:|---:|']
    for method in LABELS: lines.append('|'+LABELS[method]+'|'+'|'.join(fmt(agg[method][k]) for k in KEYS)+'|')
    return '\n'.join(lines)+'\n'

lines = ['# 本地实跑结果：机器生成表\n', '来源：保存的runs.json与逐样本结果；误差条为3个预登记种子的样本SD。不是作者表格的数值替换。\n']
for case in cases: lines += ['## 合成 '+case+'\n', table(summary['synthetic'][case])]
lines += ['## 真实简介半合成\n', table(summary['text'])]
(OUT/'results_tables.md').write_text('\n'.join(lines), encoding='utf-8')
with (ROOT/'results'/'all_runs.csv').open('w', newline='', encoding='utf-8-sig') as f:
    writer = csv.writer(f); writer.writerow(['setting', 'seed', 'method', *KEYS, 'behavior_accuracy', 'seconds'])
    for r in syn+text: writer.writerow([r.get('case', 'text'), r['seed'], r['method'], *[r['metrics'][k] for k in KEYS], r['metrics']['behavior_accuracy'], r['elapsed_seconds']])
with (ROOT/'results'/'exploratory_tests.csv').open('w', newline='', encoding='utf-8-sig') as f:
    fields = ['setting', 'metric', 'n', 'mean_difference_cdc_minus_pred', 't', 'p_two_sided', 'p_holm_28']
    writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore'); writer.writeheader(); writer.writerows(tests)

def save(name):
    plt.savefig(FIG/f'{name}.svg', bbox_inches='tight'); plt.close()

fig, axes = plt.subplots(1, 2, figsize=(12, 4.0))
for ax, key, title in zip(axes, ('MCC', 'DCI_D'), ('MCC：相关对齐', 'DCI-D：逐轴专一性')):
    x = np.arange(len(cases))
    for offset, method in zip((-0.23, 0, 0.23), LABELS):
        mean = [summary['synthetic'][c][method][key]['mean'] for c in cases]
        sd = [summary['synthetic'][c][method][key]['sd'] for c in cases]
        ax.bar(x+offset, mean, .22, yerr=sd, capsize=2, color=COLORS[method], label=LABELS[method], alpha=.9)
    ax.set_xticks(x, [c.replace(':', '\n') for c in cases]); ax.set_ylim(0, 1.08); ax.set_title(title); ax.grid(axis='y', alpha=.15)
axes[0].legend(fontsize=8, loc='lower left'); fig.suptitle('本地实跑：20000样本 × 6设置 × 3种子；误差条为样本SD', fontsize=12); fig.tight_layout()
save('computed_synthetic_scores')

fig, axes = plt.subplots(1, 4, figsize=(12, 3.8))
for ax, key in zip(axes, KEYS):
    for i, method in enumerate(LABELS):
        value = summary['text'][method][key]
        ax.bar(i, value['mean'], color=COLORS[method], alpha=.75)
        ax.scatter([i-.08, i, i+.08], value['values'], color='#172932', s=16, zorder=3)
        ax.errorbar(i, value['mean'], yerr=value['sd'], color='black', capsize=3)
    ax.set_xticks(range(3), ['AE', 'Pred', 'CDC']); ax.set_ylim(0, 1.07); ax.set_title(key.replace('DCI_', '')); ax.grid(axis='y', alpha=.15)
fig.suptitle('本地缩小实验：2400真实简介 + 合成行为；三个点为三个种子', fontsize=12); fig.tight_layout()
save('computed_text_scores')

def scatter_synthetic():
    # Prespecified seed 11 is shown, not the best-scoring seed.
    directory = SYN/'d2_linear_seed11'; data = np.load(directory/'dataset.npz'); ids = data['test'][:900]
    fig, axes = plt.subplots(2, 4, figsize=(12, 6))
    for row, factor in enumerate((0, 1)):
        points = data['true_z'][ids]
        axes[row, 0].scatter(points[:, 0], points[:, 1], c=points[:, factor], cmap='viridis', s=5, alpha=.7); axes[row, 0].set_title(f'真实z；按因素{factor+1}着色')
        for col, method in enumerate(LABELS, 1):
            output = np.load(directory/f'{method}_predictions.npz'); points = output['learned_z'][:900]
            axes[row, col].scatter(points[:, 0], points[:, 1], c=output['true_z'][:900, factor], cmap='viridis', s=5, alpha=.7); axes[row, col].set_title(LABELS[method]); axes[row, col].set_xlabel('学习轴1')
    fig.suptitle('固定示例：二维线性，seed=11，测试集前900点；不按最好结果挑图', fontsize=12); fig.tight_layout(); save('computed_synthetic_scatter')
scatter_synthetic()

fig, axes = plt.subplots(2, 3, figsize=(10.5, 6))
for col, method in enumerate(LABELS):
    output = np.load(TEXT/f'{method}_seed11_test.npz'); p = output['learned_z']
    for row, factor in enumerate((0, 1)):
        axes[row, col].scatter(p[:, 0], p[:, 1], c=output['true_z'][:, factor], cmap='viridis', s=12, alpha=.65)
        axes[row, col].set_title(LABELS[method]); axes[row, col].set_ylabel('性别编码着色' if row == 0 else '收入等级着色'); axes[row, col].set_xlabel('学习轴1')
fig.suptitle('固定示例：真实文本seed=11，全部360个测试点；未作后验旋转', fontsize=12); fig.tight_layout(); save('computed_text_scatter')

fig, axes = plt.subplots(1, 2, figsize=(11, 3.8))
directory = SYN/'d2_linear_seed11'
for method in LABELS:
    records = list(csv.DictReader((directory/f'{method}_trace.csv').open(encoding='utf-8')))
    epochs = [int(r['epoch']) for r in records]
    axes[0].plot(epochs, [float(r['validation_objective']) for r in records], color=COLORS[method], label=LABELS[method])
    if method == 'cdc': axes[1].plot(epochs, [float(r['train_contrast']) for r in records], color=COLORS[method])
axes[0].set_title('各自验证目标（不同目标数值不直接排名）'); axes[0].legend(fontsize=8)
axes[1].set_title('CDC训练对比项；第11轮启用'); axes[1].axvline(10.5, color='#a0a0a0', linestyle='--')
for ax in axes: ax.set_xlabel('轮次'); ax.grid(alpha=.15)
fig.tight_layout(); save('computed_training')

theta = np.linspace(0, np.pi/4, 361); loss = 16-8*np.cos(2*theta)-8*np.sin(2*theta)
fig, ax = plt.subplots(figsize=(8.5, 3.8)); ax.plot(np.degrees(theta), loss, color='#187d78')
for angle in (0, 22.5, 45):
    value = float(16-8*np.cos(2*np.radians(angle))-8*np.sin(2*np.radians(angle)))
    ax.scatter(angle, value, color='#c17e26'); ax.annotate(f'{angle:g}°: {value:.6f}', (angle, value), xytext=(6, 8), textcoords='offset points', fontsize=10)
ax.set_xlim(-2, 55); ax.set_ylim(4, 9.2); ax.set_xlabel('共同旋转角度'); ax.set_ylabel('全部6组对最小平方残差之和'); ax.set_title('固定尺度旋转诊断：零项更多，不代表总损失更低'); ax.grid(alpha=.2); fig.tight_layout(); save('computed_rotation')

fig, ax = plt.subplots(figsize=(8.5, 3.5)); eps = np.logspace(-3, 0, 121); ax.loglog(eps, eps**2, color='#187d78')
ax.scatter([1,.1,.01,.001], [1,.01,.0001,.000001], color='#c17e26'); ax.set_xlabel('表征与扰动共同缩放系数 ε'); ax.set_ylabel('对比平方损失 / 原损失'); ax.set_title('尺度诊断：预测logits不变，损失按ε²缩小'); ax.grid(alpha=.2); fig.tight_layout(); save('computed_scale')

# Generate the full results chapter, including every run, from the calculated values.
chapter = '''# 09｜本次实跑：全部结果、失败设置与可重算证据

> **独立重实现/缩小实验，不是作者官方代码复现。** 未取得补充代码；原论文7B/8B、真实拒答、SAE原实验未执行。下面新增数字来自实际运行，作者数字见第08章。

## 9.1 实际运行规模与环境

- CPU实跑；本机约16GiB内存、10核Xeon，无CUDA；未购买云算力、未调用付费模型API。
- 18份合成数据集，各20000样本；6设置×3方法×3种子=54次瓶颈训练，另有18次共享VAE预训练。
- 2400条真实简介，768维冻结DistilBERT特征，3方法×3种子=9次训练；训练/验证/测试为1680/360/360。
- Python、库、数据与模型提交版本、数据SHA256及全部实现约定保存在协议中。

模型只按验证目标选检查点；没有根据最终MCC/DCI改变权重、结构或挑种子。为了补存全部评价器预测和模型检查点，另以完全相同协议重新执行；两轮原始结果均保留，并逐项比较指标。

## 9.2 合成结果：均值 ± 样本SD

I为连续因素的平均测试R²，未截断。不同设置分开报告，不把相关的四个指标混成一个“综合胜率”。

'''
for case in cases:
    chapter += '### '+case+'\n\n'+table(summary['synthetic'][case])+'\n'
chapter += '''<figure class="study-figure"><img src="../assets/figures/computed_synthetic_scores.svg" alt="全部六种设置的合成MCC与D均值和标准差"><figcaption>本地实跑计算图：全部预登记种子；误差条为样本SD，不是95%置信区间。</figcaption></figure>

**结论不是“成功复现作者表1”。** CDC相对Pred在部分设置改善，但没有在所有设置/指标占优；AE在部分二维设置反而更好。独立实现的归一化、共享平移近似、未披露的作者细节、VAE信息损失和有限优化都可能影响结果，当前数据不能确定哪一项是主因。

<figure class="study-figure"><img src="../assets/figures/computed_synthetic_scatter.svg" alt="固定seed11的真实因素与三个方法学习空间"><figcaption>本地测试预测绘图：按预先固定seed=11展示，不按最好分数挑图；颜色是用于评价的真实因素，不曾作为概念训练标签。</figcaption></figure>

<figure class="study-figure"><img src="../assets/figures/computed_training.svg" alt="固定合成设置的验证轨迹与对比损失"><figcaption>实际保存的逐轮日志：AE、Pred、CDC的目标项不同，验证数值不可直接横向作为效果排名。训练收敛也不代表总体理论最优。</figcaption></figure>

## 9.3 真实简介半合成：均值 ± 样本SD

'''+table(summary['text'])+'''
I是性别编码与收入等级的平均测试分类准确率。使用公开Bias in Bios镜像的固定提交，模型为固定提交的distilbert-base-uncased，safetensors加载且不运行远程自定义代码。

**与作者表2的差异：** 2400而非20000条；只选6种职业，收入等级使用明确的固定分组，不是重新下载劳工统计后算薪资分位数；冻结最后层CLS、最大长度96；只训练小解释网络；固定结构和50轮而非原文3轮与DCI网格调参。

六职业分组：accountant/nurse→中，attorney/physician→高，painter/teacher→低。每职业、每性别编码抽200条，共12个单元。模拟四类行为只由性别和收入等级生成，**不是观察到DistilBERT真的作出了收入判断**。

<figure class="study-figure"><img src="../assets/figures/computed_text_scores.svg" alt="真实文本半合成的四项指标及全部种子散点"><figcaption>本地实跑：条为均值，黑点为各种子，误差条为样本SD。不能用本图冒充作者的原规模DistilBERT分数。</figcaption></figure>

<figure class="study-figure"><img src="../assets/figures/computed_text_scatter.svg" alt="真实文本seed11的学习空间按因素着色"><figcaption>全部360个测试点；没有为了视觉效果作后验旋转。能看出因素信息不等于每个轴都已对齐。</figcaption></figure>

整体上，文本I较高但D仍低、种子间不稳定；这恰好说明“保留因素信息”和“逐轴识别”不同。没有取得作者原代码，不能把差异归结为论文方法必然无效，也不能把本地某次改善吹成复现成功。

## 9.4 每次运行的原始分数

下面保留全部63次瓶颈训练，避免只给均值掩盖失败种子。更多小数位和逐样本预测在计算证据包中。

|设置|种子|方法|MCC|D|C|I|
|---|---:|---|---:|---:|---:|---:|
'''
for r in syn+text:
    chapter += '|'+r.get('case', '真实文本')+'|'+str(r['seed'])+'|'+r['method']+'|'+'|'.join(f'{r["metrics"][k]:.6f}' for k in KEYS)+'|\n'
chapter += '''
## 9.5 探索性配对差和多重校正

CDC减Pred，同一设置同一种子配对。双侧t检验n=3；同一组28个比较作Holm校正。正差不自动显著，显著也不证明普遍可识别。

|设置|指标|平均差 CDC−Pred|原始p|Holm校正p|
|---|---|---:|---:|---:|
'''
for t in tests:
    chapter += f'|{t["setting"]}|{t["metric"]}|{t["mean_difference_cdc_minus_pred"]:.6f}|{t["p_two_sided"]:.6f}|{t["p_holm_28"]:.6f}|\n'
chapter += '''
小样本正态性未验证；文本三次划分共用同一数据源，因此这里只是透明的探索性计算。作者原文显著性无法从已发表均值复算，本章不补造原文p值。

## 9.6 理论核验与实际耗时

理论脚本的11类检查覆盖：缺秩反例、log-odds左逆、反事实可实现性、单稀疏列结构、固定尺度旋转、尺度收缩、动态规划/穷举、梯度有限差分、DCI手算、混合函数与softmax规范自由度。

'''
chapter += f'本次所用合成完整流程实测约{summary["runtime"]["synthetic_training_protocol_seconds"]/60:.2f}分钟；冻结文本特征提取约{summary["runtime"]["text_feature_seconds"]:.1f}秒；9次文本对齐/评价合计约{summary["runtime"]["text_alignment_seconds_sum"]:.1f}秒。计时受并发、导入与硬件影响，不与作者GPU耗时作严格性能比较。\n\n'
if 'verification' in summary:
    v=summary['verification']
    chapter += f'独立复核覆盖{v["passed_model_runs"]}次模型运行，重新拟合{v["evaluator_refits"]}次训练集评价器；共比较{v["numeric_entries_compared"]:,}个原始数值/汇总项，最大绝对差{v["maximum_absolute_difference"]:.3g}。这包括数据混合、测试表征、逐因素预测分数、DCI/MCC及统计汇总，不是{v["numeric_entries_compared"]:,}次独立实验。\n\n'
chapter += '''## 9.7 下载与证据范围

- [计算证据包（代码、协议、逐样本结果、检查报告）](计算证据包.zip)
- [机器可读摘要](results/summary.json) · [全部运行CSV](results/all_runs.csv) · [验证报告](output/verification.md)

不公开原始人物简介、完整LM权重、机器路径或凭据。只有实际运行过的数字标为实跑；所有新结果的聚合、绘图、检验由脚本生成，数值复核失败会阻止最终打包。
'''
(ROOT/'chapters'/'09_computations.md').write_text(chapter, encoding='utf-8')
print(json.dumps({'synthetic': len(syn), 'text': len(text), 'figures': 7, 'summary_source': summary['source'], 'text_aggregate': summary['text']}, indent=2, ensure_ascii=False))
