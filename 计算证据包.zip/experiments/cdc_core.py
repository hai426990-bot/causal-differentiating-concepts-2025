"""Independent, explicit implementation of the published ideas, NOT author code.

Every departure from the PDF is recorded in protocol.json and the study chapter.
"""
from __future__ import annotations
import copy
import hashlib
import itertools
import json
import math
import os
import random
from pathlib import Path
import time

for _key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(_key, '1')
import numpy as np
import torch
from torch import nn
from scipy.optimize import linear_sum_assignment
from sklearn.ensemble import GradientBoostingRegressor, GradientBoostingClassifier
from sklearn.metrics import r2_score, accuracy_score
from sklearn.model_selection import train_test_split


def seed_everything(seed: int, threads: int = 1):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)


def sha256_array(array):
    a = np.ascontiguousarray(array)
    return hashlib.sha256(str(a.dtype).encode() + str(a.shape).encode() + a.tobytes()).hexdigest()


def mixing(z, kind):
    """All six mixing functions transcribed from Appendix B, page 19."""
    a, b = z[:, 0], z[:, 1]
    if z.shape[1] == 2:
        values = {
            'linear': [2*a, 5*b, a+b, 2*a+b, -a+4*b, 3*a-2*b],
            'sparse': [a, 2*a+3*a*a, 4*b, 2*b*b+b**3, 6*np.sin(a), -2*np.cos(b)],
            'dense': [a*b, a+3*b, a*a*b, a*b**3, 2*a+b, 2*a*b*b],
        }
    elif z.shape[1] == 3:
        c = z[:, 2]
        values = {
            'linear': [2*a, 5*b, 3*c, a+b+c, 2*a+b+c, -a+4*b-3*c, 3*a-2*b+5*c],
            'sparse': [a, 2*b, 6*c, a+3*a*a, b*b+4*b**3, c+5*c*c, a*np.cos(a), 6*np.sin(b), c*np.sin(c)],
            'dense': [a*b*c, a+3*b+5*c, a*a*b*c, a*b*c*np.sin(c), 2*a+b*c, 2*a*b*b*c*c],
        }
    else:
        raise ValueError('Published mixing functions cover d=2 and d=3 only')
    return np.stack(values[kind], axis=1).astype(np.float32)


def make_synthetic(n, dimension, kind, seed):
    rng = np.random.default_rng(seed)
    z = rng.normal(0, 1, size=(n, dimension)).astype(np.float32)
    # The paper does not give these numerical cutoffs or the complete d=3 label code.
    # d=2 follows its four-region drawing. d=3 is an explicitly registered extension.
    c = np.where(z[:, 1] < -0.6, 0, np.where(z[:, 1] > 0.6, 3, np.where(z[:, 0] < 0, 1, 2)))
    if dimension == 3:
        c = c + 4*(z[:, 2] > 0)
    return mixing(z, kind), z, c.astype(np.int64)


def split_indices(c, seed):
    idx = np.arange(len(c))
    train, rest = train_test_split(idx, test_size=0.30, random_state=seed, stratify=c)
    val, test = train_test_split(rest, test_size=0.50, random_state=seed+1, stratify=c[rest])
    return train, val, test


def standardize(train, *others):
    mean = train.mean(axis=0); std = train.std(axis=0)
    std = np.maximum(std, 1e-5)
    return [(a-mean)/std for a in (train, *others)], mean, std


def axis_cover(costs):
    """Exact discrete minimum under all-axis coverage, O(P*d*2**d)."""
    costs = np.asarray(costs, dtype=np.float64)
    p, d = costs.shape
    if p < d:
        raise ValueError('Too few group pairs to cover all coordinates')
    states = {0: (0.0, [])}
    for row in costs:
        nxt = {}
        for mask, (value, choices) in states.items():
            for axis in range(d):
                new_mask = mask | (1 << axis)
                new_value = value + float(row[axis])
                if new_mask not in nxt or new_value < nxt[new_mask][0]:
                    nxt[new_mask] = (new_value, choices + [axis])
        states = nxt
    return np.asarray(states[(1 << d)-1][1], dtype=np.int64)


def pair_costs(features, c, shifts, pairs, generator, anchors=12, donors=5):
    """Shared pair shift; five donor candidates per anchor, squared Euclidean residual.

    Appendix B describes five donors. Anchor subsampling and the alternating
    all-axis assignment are independent implementation conventions.
    """
    groups = int(c.max())+1
    anchor_indices, donor_indices = [], []
    for group in range(groups):
        ids = torch.where(c == group)[0]
        if not len(ids):
            return None
        anchor_indices.append(ids[torch.randint(len(ids), (anchors,), generator=generator)])
        donor_indices.append(ids[torch.randint(len(ids), (anchors, donors), generator=generator)])
    anchor_ids = torch.stack(anchor_indices)
    donor_ids = torch.stack(donor_indices)
    left, right = pairs[:, 0], pairs[:, 1]
    difference = features[donor_ids[right]] - features[anchor_ids[left]][:, :, None, :]
    residuals = (difference.square().sum(dim=-1, keepdim=True)
                 - 2*difference*shifts[:, None, None, :]
                 + shifts[:, None, None, :].square())
    return residuals.clamp_min(0).min(dim=2).values.mean(dim=1)


class VAE(nn.Module):
    def __init__(self, n, hidden=16, latent=16):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(n, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.mu = nn.Linear(hidden, latent); self.logvar = nn.Linear(hidden, latent)
        self.decoder = nn.Sequential(nn.Linear(latent, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, n))

    def forward(self, x):
        h = self.body(x); mu, lv = self.mu(h), self.logvar(h).clamp(-8, 8)
        z = mu + torch.randn_like(mu)*torch.exp(0.5*lv) if self.training else mu
        return self.decoder(z), mu, lv


def pretrain_vae(x, split, seed, epochs, batch_size=256):
    seed_everything(seed)
    tr, va, te = split
    scaled, mean, std = standardize(x[tr], x[va], x[te])
    model = VAE(x.shape[1]); opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    train = torch.tensor(scaled[0]); valid = torch.tensor(scaled[1]); trace = []
    best, best_state = float('inf'), None
    for epoch in range(epochs):
        model.train(); order = np.random.default_rng(seed+epoch).permutation(len(tr)); total = 0.
        for start in range(0, len(tr), batch_size):
            batch = train[order[start:start+batch_size]]
            reconstruction, mu, lv = model(batch)
            rec = (reconstruction-batch).square().mean()
            kl = -0.5*(1+lv-mu.square()-lv.exp()).mean()
            loss = rec+1e-3*kl
            opt.zero_grad(); loss.backward(); opt.step(); total += float(loss.detach())*len(batch)
        model.eval()
        with torch.no_grad():
            reconstruction, mu, lv = model(valid)
            value = float((reconstruction-valid).square().mean()+1e-3*(-0.5*(1+lv-mu.square()-lv.exp()).mean()))
        trace.append({'epoch': epoch+1, 'train': total/len(tr), 'validation': value})
        if value < best:
            best, best_state = value, copy.deepcopy(model.state_dict())
    model.load_state_dict(best_state); model.eval()
    with torch.no_grad():
        g = [model(torch.tensor(a))[1].numpy() for a in scaled]
    g, gm, gs = standardize(*g)
    return g, scaled, trace, {'input_mean': mean.tolist(), 'input_std': std.tolist(), 'feature_mean': gm.tolist(), 'feature_std': gs.tolist(), 'best_validation': best}


class Alignment(nn.Module):
    def __init__(self, gdim, xdim, dimension, groups, hidden=4):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(gdim, hidden), nn.ReLU(), nn.Linear(hidden, dimension))
        # This scale normalization is ADDED in this independent implementation.
        self.normalize = nn.BatchNorm1d(dimension, affine=False, eps=1e-4, momentum=0.05)
        self.decoder = nn.Sequential(nn.Linear(dimension, 16), nn.ReLU(), nn.Linear(16, xdim))
        self.predictor = nn.Linear(dimension, groups)
        self.register_buffer('pairs', torch.tensor(list(itertools.combinations(range(groups), 2)), dtype=torch.long))
        self.shifts = nn.Parameter(torch.ones(len(self.pairs), dimension))

    def forward(self, x):
        raw = self.encoder(x); z = self.normalize(raw)
        return z, self.decoder(z), self.predictor(z), raw


def fit_alignment(g, targets, ztrue, classes, dimension, seed, method, epochs=50, batch_size=256, hidden=4, categorical=False, artifact_dir=None):
    seed_everything(seed)
    groups = int(max(a.max() for a in classes))+1
    model = Alignment(g[0].shape[1], targets[0].shape[1], dimension, groups, hidden)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=8)
    tensor_g = [torch.tensor(a, dtype=torch.float32) for a in g]
    tensor_x = [torch.tensor(a, dtype=torch.float32) for a in targets]
    tensor_c = [torch.tensor(a, dtype=torch.long) for a in classes]
    prediction_weight = 0. if method == 'ae' else 1.
    constraint_weight = 0.2 if method == 'cdc' else 0.
    warmup = min(10, max(1, epochs//5))
    axes = torch.tensor(axis_cover(np.zeros((len(model.pairs), dimension))))
    best = float('inf'); best_state = None; best_axes = None; trace = []; skipped = 0
    for epoch in range(epochs):
        if method == 'cdc' and epoch == warmup:
            model.eval()
            with torch.no_grad():
                f = model(tensor_g[0])[0]
                means = torch.stack([f[tensor_c[0] == k].mean(0) for k in range(groups)])
                initial = means[model.pairs[:, 1]]-means[model.pairs[:, 0]]
                signs = torch.where(initial >= 0, 1., -1.)
                model.shifts.copy_(signs*initial.abs().clamp_min(0.1))
        model.train(); order = np.random.default_rng(seed+epoch).permutation(len(g[0]))
        accum = np.zeros(4); cost_sum = np.zeros((len(model.pairs), dimension)); cost_count = 0
        active = method == 'cdc' and epoch >= warmup
        generator = torch.Generator().manual_seed(seed*1000+epoch)
        for start in range(0, len(order), batch_size):
            ids = order[start:start+batch_size]
            if len(ids) < 2: continue
            f, reconstruction, logits, raw = model(tensor_g[0][ids])
            rec = (reconstruction-tensor_x[0][ids]).square().mean()
            ce = nn.functional.cross_entropy(logits, tensor_c[0][ids])
            var_penalty = torch.relu(0.25-raw.std(0, unbiased=False)).square().mean()
            contrast = f.sum()*0
            if active:
                costs = pair_costs(f, tensor_c[0][ids], model.shifts, model.pairs, generator)
                if costs is None: skipped += 1
                else:
                    contrast = costs[torch.arange(len(axes)), axes].mean()
                    cost_sum += costs.detach().numpy(); cost_count += 1
            loss = rec + prediction_weight*ce + (constraint_weight if active else 0)*contrast + 0.5*var_penalty
            opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(), 10.); opt.step()
            if active:
                with torch.no_grad():
                    signs = torch.where(model.shifts >= 0, 1., -1.)
                    model.shifts.copy_(signs*model.shifts.abs().clamp_min(0.1))
            accum += np.array([float(loss.detach()), float(rec.detach()), float(ce.detach()), float(contrast.detach())])*len(ids)
        if active and cost_count:
            axes = torch.tensor(axis_cover(cost_sum/cost_count))
        model.eval()
        with torch.no_grad():
            f, reconstruction, logits, raw = model(tensor_g[1])
            rec = (reconstruction-tensor_x[1]).square().mean()
            ce = nn.functional.cross_entropy(logits, tensor_c[1])
            costs = pair_costs(f, tensor_c[1], model.shifts, model.pairs, torch.Generator().manual_seed(seed+999999)) if active else None
            contrast = costs[torch.arange(len(axes)), axes].mean() if costs is not None else rec*0
            value = float(rec+prediction_weight*ce+(constraint_weight if active else 0)*contrast)
        trace.append({'epoch': epoch+1, 'train_total': accum[0]/len(order), 'train_reconstruction': accum[1]/len(order), 'train_ce': accum[2]/len(order), 'train_contrast': accum[3]/len(order), 'validation_objective': value, 'constraint_active': active, 'learning_rate': opt.param_groups[0]['lr']})
        # Do not compare the warm-up objective against the constrained objective.
        eligible = method != 'cdc' or active
        if eligible and value < best:
            best, best_state, best_axes = value, copy.deepcopy(model.state_dict()), axes.clone()
        scheduler.step(value)
    if best_state is None: raise RuntimeError('No eligible validation checkpoint')
    model.load_state_dict(best_state); model.eval()
    with torch.no_grad():
        outputs = [model(a) for a in tensor_g]
    features = [a[0].numpy() for a in outputs]
    predictions = [a[2].argmax(-1).numpy() for a in outputs]
    if artifact_dir is not None:
        artifact_dir = Path(artifact_dir); artifact_dir.mkdir(parents=True, exist_ok=True)
        from safetensors.torch import save_file
        save_file({k: v.contiguous() for k, v in model.state_dict().items()}, str(artifact_dir/'model.safetensors'))
        np.savez_compressed(artifact_dir/'representations.npz', train=features[0], validation=features[1], test=features[2], true_train=ztrue[0], true_validation=ztrue[1], true_test=ztrue[2])
    scores = metrics(features[0], features[2], ztrue[0], ztrue[2], seed, categorical=categorical, artifact_dir=artifact_dir)
    scores['behavior_accuracy'] = float(accuracy_score(classes[2], predictions[2])) if method != 'ae' else None
    shifts = model.shifts.detach().numpy()[np.arange(len(best_axes)), best_axes.numpy()]
    delta = np.zeros((len(best_axes), dimension)); delta[np.arange(len(best_axes)), best_axes.numpy()] = shifts
    details = {'selected_epoch': int(min((t for t in trace if method != 'cdc' or t['constraint_active']), key=lambda t: t['validation_objective'])['epoch']), 'validation_objective': best, 'test_feature_std': features[2].std(0).tolist(), 'axis_assignments': best_axes.tolist(), 'shift_matrix': delta.tolist(), 'shift_rank': int(np.linalg.matrix_rank(delta)), 'skipped_class_incomplete_batches': skipped}
    return scores, features[2], predictions[2], trace, details


def metrics(ftrain, ftest, ztrain, ztest, seed, categorical=False, artifact_dir=None):
    learned, factors = ftrain.shape[1], ztrain.shape[1]
    correlation = np.corrcoef(ftest.T, ztest.T)[:learned, learned:]
    correlation = np.nan_to_num(correlation)
    rows, cols = linear_sum_assignment(-np.abs(correlation))
    mcc = float(np.abs(correlation[rows, cols]).sum()/max(learned, factors))
    importance = np.zeros((learned, factors)); information = []; factor_predictions = []
    for j in range(factors):
        if categorical:
            evaluator = GradientBoostingClassifier(n_estimators=100, max_depth=3, random_state=seed)
        else:
            evaluator = GradientBoostingRegressor(n_estimators=100, max_depth=3, random_state=seed)
        evaluator.fit(ftrain, ztrain[:, j]); pred = evaluator.predict(ftest); factor_predictions.append(pred)
        importance[:, j] = evaluator.feature_importances_
        information.append(float(accuracy_score(ztest[:, j], pred) if categorical else r2_score(ztest[:, j], pred)))
    disentanglement, completeness = entropy_scores(importance)
    if artifact_dir is not None:
        np.savez_compressed(Path(artifact_dir)/'factor_evaluation.npz', truth=ztest, prediction=np.stack(factor_predictions, axis=1), importance=importance, correlation=correlation)
    return {'MCC': mcc, 'DCI_D': disentanglement, 'DCI_C': completeness, 'DCI_I': float(np.mean(information)), 'factor_information': information, 'importance': importance.tolist(), 'correlation': correlation.tolist(), 'information_definition': 'mean classification accuracy' if categorical else 'mean test R2; not clipped'}


def entropy_scores(importance):
    r = np.asarray(importance, dtype=float)
    if r.sum() <= 0: return 0., 0.
    code_mass, factor_mass = r.sum(1), r.sum(0)
    p = np.divide(r, code_mass[:, None], out=np.zeros_like(r), where=code_mass[:, None] > 0)
    q = np.divide(r, factor_mass[None, :], out=np.zeros_like(r), where=factor_mass[None, :] > 0)
    hrow = -(p*np.log(np.maximum(p, 1e-300))).sum(1)/math.log(r.shape[1]) if r.shape[1] > 1 else np.zeros(r.shape[0])
    hcol = -(q*np.log(np.maximum(q, 1e-300))).sum(0)/math.log(r.shape[0]) if r.shape[0] > 1 else np.zeros(r.shape[1])
    return float(np.dot(1-hrow, code_mass/r.sum())), float(np.dot(1-hcol, factor_mass/r.sum()))
