"""Frozen DistilBERT + real public biographies, with explicitly synthetic behavior.

No pickle loading, no remote-code execution, no raw person biographies published.
"""
import os
for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key, '2')
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
import pyarrow.parquet as pq
import torch
from huggingface_hub import hf_hub_download
from transformers import AutoTokenizer, AutoModel

ROOT = Path(__file__).resolve().parents[1]
MODEL = 'distilbert/distilbert-base-uncased'
MODEL_REV = '12040accade4e8a0f71eabdb258fecc2e7e948be'
DATA = 'LabHC/bias_in_bios'
DATA_REV = '052f01de644dba841176e0449528b41f27d94a61'
DATA_FILE = 'data/train-00000-of-00001-0ab65b32c47407e8.parquet'
DATA_SHA = '82234971e7466262a50fe5c469a9729f3123b5d0edcd753dfa82d670dbfa048c'
PROFESSIONS = {0: ('accountant', 1), 2: ('attorney', 2), 13: ('nurse', 1), 14: ('painter', 0), 19: ('physician', 2), 26: ('teacher', 0)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--per-cell', type=int, default=200)
    parser.add_argument('--max-length', type=int, default=96)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--cache', required=True)
    args = parser.parse_args()
    torch.set_num_threads(2); torch.manual_seed(20251029)
    output = ROOT/'results'/'text_features'; output.mkdir(parents=True, exist_ok=True)
    print('Downloading pinned parquet dataset; no pickle is executed.', flush=True)
    file = hf_hub_download(DATA, DATA_FILE, repo_type='dataset', revision=DATA_REV, cache_dir=args.cache)
    checksum = hashlib.sha256(Path(file).read_bytes()).hexdigest()
    if checksum != DATA_SHA: raise RuntimeError('Dataset checksum differs from public LFS metadata')
    table = pq.read_table(file, columns=['hard_text', 'profession', 'gender'])
    profession = table['profession'].to_numpy(); gender = table['gender'].to_numpy()
    rng = np.random.default_rng(20251029); selected = []; counts = []
    for job, (name, income) in PROFESSIONS.items():
        for sex in (0, 1):
            available = np.where((profession == job)&(gender == sex))[0]
            if len(available) < args.per_cell: raise RuntimeError(f'Insufficient rows in profession {job}, gender {sex}')
            chosen = rng.choice(available, args.per_cell, replace=False)
            selected.extend(chosen.tolist()); counts.append({'profession': name, 'profession_id': job, 'gender_code': sex, 'income_code': income, 'n': args.per_cell})
    selected = np.array(selected, dtype=np.int64); rng.shuffle(selected)
    subset = table.take(selected); texts = subset['hard_text'].to_pylist()
    job = profession[selected]; sex = gender[selected]
    income = np.array([PROFESSIONS[int(v)][1] for v in job])
    true_z = np.stack([sex, income], axis=1).astype(np.int64)
    behavior = np.where(income == 0, 0, np.where(income == 2, 3, np.where(sex == 0, 2, 1))).astype(np.int64)
    print('Loading pinned safetensors model on CPU, trust_remote_code=False.', flush=True)
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=MODEL_REV, cache_dir=args.cache, trust_remote_code=False)
    model = AutoModel.from_pretrained(MODEL, revision=MODEL_REV, cache_dir=args.cache, use_safetensors=True, trust_remote_code=False)
    model.eval(); features = []; start = time.perf_counter(); truncated = 0
    for begin in range(0, len(texts), args.batch_size):
        batch_texts = texts[begin:begin+args.batch_size]
        encoded = tokenizer(batch_texts, padding=True, truncation=True, max_length=args.max_length, return_tensors='pt')
        truncated += int((encoded['attention_mask'].sum(-1) == args.max_length).sum())
        with torch.no_grad(): values = model(**encoded).last_hidden_state[:, 0, :].numpy()
        features.append(values)
        if begin % (args.batch_size*10) == 0: print(f'FEATURES {min(begin+args.batch_size,len(texts))}/{len(texts)} elapsed={time.perf_counter()-start:.1f}s', flush=True)
    features = np.concatenate(features).astype(np.float32)
    np.savez_compressed(output/'features.npz', activations=features, true_z=true_z, behavior=behavior, dataset_row=selected)
    np.savetxt(output/'selected_rows.csv', np.c_[selected, job, sex, income, behavior], delimiter=',', fmt='%d', header='dataset_row,profession_id,gender_code,income_code,behavior', comments='')
    manifest = {'kind': 'reduced semi-synthetic adaptation, not exact paper Table 2 reproduction', 'model': MODEL, 'model_revision': MODEL_REV, 'dataset': DATA, 'dataset_revision': DATA_REV, 'dataset_file': DATA_FILE, 'dataset_sha256': checksum, 'dataset_license_in_HF_card': 'MIT', 'paper_dataset_license_reported': 'Apache-2.0; differs from this mirror; not assumed equivalent', 'n': len(texts), 'per_cell': args.per_cell, 'cells': counts, 'income_mapping': 'explicit six-profession grouping from paper examples, NOT reproduced US salary quantiles', 'behavior': 'synthetic four-class labels from income and gender, NOT observed DistilBERT refusals or salaries', 'features': 'frozen last-layer CLS vector, 768 dimensions', 'max_length': args.max_length, 'rows_at_length_cap': truncated, 'batch_size': args.batch_size, 'device': 'cpu', 'threads': 2, 'elapsed_feature_seconds': time.perf_counter()-start, 'feature_sha256': hashlib.sha256(np.ascontiguousarray(features).tobytes()).hexdigest(), 'raw_biographies_published': False}
    (output/'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(f'COMPLETE {features.shape}; no raw biography text was written to public results.', flush=True)

if __name__ == '__main__': main()
