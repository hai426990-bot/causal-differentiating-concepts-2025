"""Recompute published local numbers from saved raw predictions; optionally refit all evaluators."""
import os
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ.setdefault(key,'1')
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import json
import platform
import statistics
import time
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy import stats
from sklearn.metrics import r2_score, accuracy_score
from cdc_core import entropy_scores, metrics, mixing, sha256_array

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
parser=argparse.ArgumentParser();parser.add_argument('--refit',action='store_true');args=parser.parse_args()
started=time.perf_counter();checks=[];errors=[];largest=0.;numbers=0
def assert_that(value,name):
    if not bool(value): raise AssertionError(name)
def close(a,b,name,tol=1e-11):
    global largest,numbers
    aa,bb=np.asarray(a,dtype=float),np.asarray(b,dtype=float)
    assert_that(aa.shape==bb.shape,name+' shape')
    error=float(np.abs(aa-bb).max()) if aa.size else 0.
    assert_that(np.isfinite(error) and error<=tol,name+f' error={error}')
    largest=max(largest,error);numbers+=aa.size
def load(file): return json.loads(file.read_text(encoding='utf-8'))

syn=ROOT/'results'/'synthetic_confirmed'; text=ROOT/'results'/'text_confirmed'
assert_that((syn/'completed.json').exists() and (text/'completed.json').exists(),'Both confirmed protocols must have finished before verification')
runs=load(syn/'runs.json');truns=load(text/'runs.json');assert_that(len(runs)==54 and len(truns)==9,'63 completed model fits')

for kind, records, folder in [('synthetic',runs,syn),('text',truns,text)]:
    first=load(ROOT/'results'/kind/'runs.json')
    assert_that(len(first)==len(records),kind+' initial length')
    for initial,r in zip(first,records):
        key=f'{kind}:{r.get("case", "text")}:{r["seed"]}:{r["method"]}'
        try:
            assert_that(all(initial.get(k)==r.get(k) for k in ('case','seed','method')),key+' rerun identity')
            for metric in ('MCC','DCI_D','DCI_C','DCI_I'):close(initial['metrics'][metric],r['metrics'][metric],key+' deterministic rerun '+metric)
            if kind=='synthetic':
                directory=folder/f'd{r["dimension"]}_{r["mixing"]}_seed{r["seed"]}'
                raw=np.load(directory/f'{r["method"]}_predictions.npz')
                artifact=directory/f'{r["method"]}_artifacts'
            else:
                raw=np.load(folder/f'{r["method"]}_seed{r["seed"]}_test.npz')
                artifact=folder/f'{r["method"]}_seed{r["seed"]}_artifacts'
            evaluation=np.load(artifact/'factor_evaluation.npz');rep=np.load(artifact/'representations.npz')
            close(rep['test'],raw['learned_z'],key+' saved test features')
            close(rep['true_test'],raw['true_z'],key+' test truths')
            close(evaluation['truth'],raw['true_z'],key+' evaluation truths')
            close(evaluation['importance'],r['metrics']['importance'],key+' importance')
            d,c=entropy_scores(evaluation['importance']);close(d,r['metrics']['DCI_D'],key+' D');close(c,r['metrics']['DCI_C'],key+' C')
            ft,z=raw['learned_z'],raw['true_z'];dim=ft.shape[1]
            correlation=np.nan_to_num(np.corrcoef(ft.T,z.T)[:dim,dim:]);a,b=linear_sum_assignment(-np.abs(correlation))
            mcc=float(np.abs(correlation[a,b]).sum()/max(ft.shape[1],z.shape[1]))
            close(mcc,r['metrics']['MCC'],key+' MCC');close(correlation,evaluation['correlation'],key+' correlation')
            information=[float(accuracy_score(z[:,j],evaluation['prediction'][:,j]) if kind=='text' else r2_score(z[:,j],evaluation['prediction'][:,j])) for j in range(z.shape[1])]
            close(information,r['metrics']['factor_information'],key+' factor information');close(np.mean(information),r['metrics']['DCI_I'],key+' I')
            if r['method']!='ae':close(accuracy_score(raw['behavior'],raw['predicted_behavior']),r['metrics']['behavior_accuracy'],key+' behavior accuracy')
            delta=np.array(r['diagnostics']['shift_matrix']);assert_that(np.linalg.matrix_rank(delta)==dim,key+' shift rank')
            assert_that(np.all(np.count_nonzero(delta,axis=1)==1),key+' one-sparse nonzero shifts')
            assert_that((artifact/'model.safetensors').stat().st_size>0,key+' checkpoint')
            if args.refit:
                repeated=metrics(rep['train'],rep['test'],rep['true_train'],rep['true_test'],r['seed'],categorical=kind=='text')
                for metric in ('MCC','DCI_D','DCI_C','DCI_I','importance'):close(repeated[metric],r['metrics'][metric],key+' independent evaluator refit '+metric)
            checks.append({'id':key,'passed':True,'evaluator_refitted':args.refit})
        except Exception as exc:errors.append({'id':key,'error':str(exc)})

# Data generation, index coverage and training-only split bookkeeping.
for directory in sorted(syn.glob('d*_seed*')):
    try:
        parts=directory.name.split('_');dimension=int(parts[0][1:]);kind=parts[1]
        data=np.load(directory/'dataset.npz');tr,va,te=data['train'],data['validation'],data['test']
        assert_that([len(tr),len(va),len(te)]==[14000,3000,3000],directory.name+' split sizes')
        assert_that(np.array_equal(np.sort(np.r_[tr,va,te]),np.arange(20000)),directory.name+' partition')
        close(mixing(data['true_z'],kind),data['x'],directory.name+' exact mixing',tol=0.)
        record=next(r for r in runs if r['dimension']==dimension and r['mixing']==kind and r['seed']==int(parts[2][4:]))
        for field,arr in [('x',data['x']),('z',data['true_z']),('c',data['behavior'])]:assert_that(sha256_array(arr)==record['data'][field],directory.name+' data hash '+field)
        checks.append({'id':'dataset:'+directory.name,'passed':True})
    except Exception as exc:errors.append({'id':directory.name,'error':str(exc)})

summary=load(ROOT/'results'/'summary.json')
for case,records in [*[(c,[r for r in runs if r['case']==c]) for c in summary['synthetic']],('text',truns)]:
    agg=summary['text'] if case=='text' else summary['synthetic'][case]
    for method in ('ae','pred','cdc'):
        for key in ('MCC','DCI_D','DCI_C','DCI_I'):
            values=[r['metrics'][key] for r in records if r['method']==method]
            close(statistics.mean(values),agg[method][key]['mean'],case+' summary mean')
            close(statistics.stdev(values),agg[method][key]['sd'],case+' summary sample SD')
for test in summary['exploratory_tests']:
    t=stats.ttest_1samp(test['paired_differences'],0)
    close(t.statistic,test['t'],'paired t');close(t.pvalue,test['p_two_sided'],'paired p')
tests=summary['exploratory_tests'];assert_that(len(tests)==28,'Holm family size')
previous=0.
for rank,index in enumerate(sorted(range(28),key=lambda i:tests[i]['p_two_sided'])):
    value=min(1.,max(previous,(28-rank)*tests[index]['p_two_sided']));close(value,tests[index]['p_holm_28'],'Holm p');previous=value

theory=load(ROOT/'results'/'theory'/'checks.json');assert_that(theory['passed']==theory['total']==11,'11 theory diagnostics')
manifest=load(ROOT/'results'/'text_features'/'manifest.json');assert_that(manifest['n']==2400 and not manifest['raw_biographies_published'],'text size and privacy')
cells=manifest['cells'];assert_that(len(cells)==12 and sum(c['n'] for c in cells)==2400,'balanced text cells')
protocol=load(syn/'protocol.json');assert_that(protocol['seeds']==[11,23,37] and protocol['n']==20000,'prespecified protocol')
assert_that(hashlib.sha256((ROOT/'experiments'/'cdc_core.py').read_bytes()).hexdigest()==protocol['code_sha256'],'final run code hash')

passed_runs=sum(not c['id'].startswith('dataset:') for c in checks)
report={'passed_model_runs':passed_runs,'model_runs_expected':63,'dataset_checks':sum(c['id'].startswith('dataset:') for c in checks),'numeric_entries_compared':int(numbers),'maximum_absolute_difference':largest,'evaluator_refits':passed_runs if args.refit else 0,'theory_diagnostics':11,'errors':errors,'elapsed_verification_seconds':time.perf_counter()-started,'checks':checks,'scope':'Raw saved test predictions, importance matrices, refitted train-only evaluators, all-run aggregates and exploratory tests; not a proof of general identifiability, not original author data verification'}
(OUT/'results_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
packages=sorted({dist.metadata['Name']:dist.version for dist in importlib.metadata.distributions()}.items(),key=lambda x:x[0].lower())
(ROOT/'experiments'/'environment_freeze.txt').write_text('\n'.join(f'{name}=={version}' for name,version in packages)+'\n',encoding='utf-8')
(ROOT/'experiments'/'environment.json').write_text(json.dumps({'python':platform.python_version(),'platform':platform.system(),'architecture':platform.machine(),'gpu_used':False,'paid_apis_used':False,'hardware_reported':{'cpu':'Intel Xeon E5-2666 v3','logical_processors':10,'ram_gib':15.84,'gpu':'AMD RX580 2048SP, non-CUDA; not used for training'}},indent=2),encoding='utf-8')
text_report=f'''# 计算验证报告

- 实际瓶颈训练：54次合成 + 9次真实文本半合成 = 63次；18次共享VAE预训练另计。
- 验证模型运行：{passed_runs}/63；数据集划分/混合函数：18份。
- 原始数值比较：{numbers:,}项；最大绝对差：{largest:.3g}。
- 训练集评价器独立重拟合：{report['evaluator_refits']}次。
- 同协议首轮与补存证据轮：各指标逐项比较，未更改训练超参数。
- 理论诊断：11/11；一般数学结论另需证明，不能用有限检验替代。
- 错误：{len(errors)}。

新增分数由逐样本预测、真实因素、重要性矩阵和训练轨迹重算。原文表格、原文显著性、大型LLM/SAE实验不在本次复现范围内。

隐私：公开包不包含原始人物简介、完整语言模型权重或机器凭据。版本、选样行号和派生结果可供复核。
'''
(OUT/'verification.md').write_text(text_report,encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
if errors:raise SystemExit(1)
